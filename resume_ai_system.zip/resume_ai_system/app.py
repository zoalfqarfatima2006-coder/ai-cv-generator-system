from frontend.dashboard import ResumeDashboard


def main() -> None:
    """Controller entry point for the Streamlit application."""
    dashboard = ResumeDashboard()
    dashboard.render()


if __name__ == "__main__":
    main()
