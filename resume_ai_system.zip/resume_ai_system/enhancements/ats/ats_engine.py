from __future__ import annotations

from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume, ResumeScore


@dataclass(slots=True)
class ATSAnalysis:
    ats_score: int
    interview_probability: int
    red_flags: list[str]
    strengths: list[str]
    improvements: list[str]


class ATSEngine:
    """Extends the existing scorer output with interview readiness signals."""

    def analyze(self, parsed: ParsedResume, match: MatchResult, score: ResumeScore) -> ATSAnalysis:
        probability = round((score.ats_score * 0.45) + (match.match_percentage * 0.45) + (match.skill_coverage * 100 * 0.1))
        red_flags = list(score.risks)
        if len(parsed.skills) < 6:
            red_flags.append("Skill section looks too light for automated screening.")
        if not parsed.education:
            red_flags.append("Education or certification details are missing.")
        if match.match_percentage < 50:
            red_flags.append("Resume language is weakly aligned with the target job description.")

        improvements = []
        if match.missing_skills:
            improvements.append(f"Add truthful proof for missing skills: {', '.join(match.missing_skills[:6])}.")
        improvements.append("Add numbers to bullets: cost saved, users served, revenue influenced, speed improved, or accuracy gained.")
        improvements.append("Keep one consistent title target across summary, skills, and experience bullets.")

        return ATSAnalysis(
            ats_score=score.ats_score,
            interview_probability=max(0, min(100, probability)),
            red_flags=red_flags or ["No critical ATS red flags detected."],
            strengths=score.strengths,
            improvements=improvements,
        )
