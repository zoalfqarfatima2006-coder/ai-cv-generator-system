"""Dashboard analytics extensions."""
