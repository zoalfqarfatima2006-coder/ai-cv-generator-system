from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from enhancements.database.history_db import EnhancementHistoryDB


@dataclass(slots=True)
class ProgressDashboardService:
    history_db: EnhancementHistoryDB

    def trend_frame(self) -> pd.DataFrame:
        rows = self.history_db.fetch_trends()
        return pd.DataFrame(rows)
