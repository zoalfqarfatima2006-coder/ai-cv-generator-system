"""Cover letter generation."""
