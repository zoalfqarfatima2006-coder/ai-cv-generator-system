from __future__ import annotations

from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume


@dataclass(slots=True)
class CoverLetterGenerator:
    """Offline ATS-focused cover letter generator with selectable tone."""

    def generate(self, parsed: ParsedResume, job_description: str, match: MatchResult, tone: str = "Professional") -> str:
        tone = tone if tone in {"Formal", "Professional", "Enthusiastic"} else "Professional"
        candidate = parsed.name or "Candidate"
        skills = ", ".join((match.matched_skills or parsed.skills)[:6]) or "relevant technical and professional skills"
        missing = ", ".join(match.missing_skills[:3])
        opener = {
            "Formal": "I am writing to express my interest in this opportunity.",
            "Professional": "I am excited to apply for this role because my background aligns closely with your needs.",
            "Enthusiastic": "I am thrilled to apply for this role and bring focused energy to your team.",
        }[tone]
        alignment = (
            f"My resume shows hands-on experience with {skills}. "
            f"The role appears to value these capabilities, and I can contribute through practical execution, clear communication, and measurable outcomes."
        )
        if missing:
            alignment += f" I am also prepared to strengthen adjacent areas such as {missing} where the role requires them."
        return (
            f"Dear Hiring Manager,\n\n"
            f"{opener}\n\n"
            f"{alignment}\n\n"
            f"I would welcome the chance to discuss how my experience, project work, and problem-solving approach can support your hiring goals. "
            f"Thank you for considering my application.\n\n"
            f"Sincerely,\n{candidate}"
        )
