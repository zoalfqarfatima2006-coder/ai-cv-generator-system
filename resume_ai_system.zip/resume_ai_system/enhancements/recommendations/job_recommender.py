from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class JobRecommendation:
    title: str
    company: str
    location: str
    match_percentage: int
    matched_skills: list[str]
    missing_skills: list[str]
    rationale: str


class JobRecommendationEngine:
    """Ranks structured job data by resume skill compatibility."""

    def __init__(self, jobs_path: str | Path = "data/jobs.json") -> None:
        self.jobs_path = Path(jobs_path)

    def recommend(self, resume_skills: list[str], limit: int = 5) -> list[JobRecommendation]:
        resume_skill_set = {skill.lower() for skill in resume_skills}
        recommendations: list[JobRecommendation] = []
        for job in self._load_jobs():
            required = {skill.lower() for skill in job.get("skills", [])}
            matched_keys = sorted(resume_skill_set & required)
            missing_keys = sorted(required - resume_skill_set)
            match = round((len(matched_keys) / len(required)) * 100) if required else 0
            display = {skill.lower(): skill for skill in job.get("skills", [])}
            matched = [display.get(skill, skill.title()) for skill in matched_keys]
            missing = [display.get(skill, skill.title()) for skill in missing_keys]
            rationale = (
                f"Strong overlap in {', '.join(matched[:4])}."
                if matched
                else "This role needs a different skill mix than the detected resume profile."
            )
            recommendations.append(
                JobRecommendation(
                    title=job["title"],
                    company=job["company"],
                    location=job["location"],
                    match_percentage=match,
                    matched_skills=matched,
                    missing_skills=missing,
                    rationale=rationale,
                )
            )
        return sorted(recommendations, key=lambda item: item.match_percentage, reverse=True)[:limit]

    def _load_jobs(self) -> list[dict]:
        if not self.jobs_path.exists():
            return []
        return json.loads(self.jobs_path.read_text(encoding="utf-8"))
