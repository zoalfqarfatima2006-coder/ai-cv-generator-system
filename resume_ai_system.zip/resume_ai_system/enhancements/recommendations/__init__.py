"""Offline job recommendation and learning path services."""
