from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class LearningResource:
    skill: str
    recommendation: str
    resource_type: str


class LearningPathEngine:
    """Maps missing skills to practical learning actions."""

    COURSE_MAP = {
        "aws": "AWS Cloud Practitioner fundamentals and one small deployment project",
        "docker": "Docker containers, images, volumes, and Compose basics",
        "sql": "SQL joins, grouping, window functions, and query optimization",
        "react": "React components, hooks, forms, and API integration",
        "fastapi": "FastAPI routing, Pydantic models, authentication, and testing",
        "power bi": "Power BI data modeling, DAX basics, and KPI dashboard design",
        "machine learning": "Supervised learning workflow, evaluation metrics, and feature engineering",
        "communication": "STAR storytelling, stakeholder updates, and concise executive summaries",
    }

    def build(self, missing_skills: list[str]) -> list[LearningResource]:
        resources: list[LearningResource] = []
        for skill in missing_skills[:8]:
            key = skill.lower()
            recommendation = self.COURSE_MAP.get(key, f"Complete a short course and build one mini project using {skill}.")
            resources.append(LearningResource(skill=skill, recommendation=recommendation, resource_type="Course + project"))
        return resources
