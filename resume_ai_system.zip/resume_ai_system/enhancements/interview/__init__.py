"""Interview preparation generators."""
