from __future__ import annotations

from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume


@dataclass(slots=True)
class InterviewQuestion:
    category: str
    question: str
    why_asked: str
    ideal_answer_structure: str
    common_mistake: str


class InterviewPrepGenerator:
    """Generates targeted interview preparation cards."""

    def generate(self, parsed: ParsedResume, match: MatchResult) -> list[InterviewQuestion]:
        primary_skills = (match.matched_skills or parsed.skills or ["the tools listed in your resume"])[:3]
        missing_skills = match.missing_skills[:2]
        questions = [
            InterviewQuestion(
                "Technical",
                f"Walk me through a project where you used {primary_skills[0]}.",
                "Interviewers want proof that the skill is practical, not just listed.",
                "Context, task, tools used, implementation choices, measurable result, lesson learned.",
                "Answering with definitions instead of a real project story.",
            ),
            InterviewQuestion(
                "Behavioral",
                "Tell me about a time you handled unclear requirements or changing priorities.",
                "The role likely needs communication and ownership under ambiguity.",
                "Situation, stakeholders, tradeoff, action, outcome, reflection.",
                "Blaming others or skipping the final business impact.",
            ),
            InterviewQuestion(
                "Situational",
                "If you joined and found the current workflow inefficient, what would you do in your first two weeks?",
                "This tests judgment, collaboration, and ability to improve systems without disrupting the team.",
                "Observe, measure, ask questions, identify one low-risk improvement, validate, then scale.",
                "Proposing a full rebuild before understanding constraints.",
            ),
        ]
        if missing_skills:
            questions.append(
                InterviewQuestion(
                    "Technical",
                    f"This role mentions {', '.join(missing_skills)}. How would you close that gap quickly?",
                    "Hiring teams check whether gaps are manageable and whether you learn deliberately.",
                    "Acknowledge gap, connect related experience, describe learning plan, explain first practical deliverable.",
                    "Pretending to have experience you cannot defend.",
                )
            )
        return questions
