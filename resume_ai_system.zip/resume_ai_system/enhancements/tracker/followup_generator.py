from __future__ import annotations

from backend.providers import get_provider


class FollowUpGenerator:
    """Generates follow-up emails with optional provider personalization."""

    def __init__(self) -> None:
        self.provider = get_provider()

    def generate(self, company: str, role: str, days_since_application: int, use_llm: bool = False) -> str:
        if use_llm:
            prompt = (
                f"Write a concise professional follow-up email for a {role} application at {company}. "
                f"The candidate applied {days_since_application} days ago."
            )
            return self.provider.generate_text(prompt)
        timing = "recently"
        if days_since_application >= 14:
            timing = "two weeks ago"
        elif days_since_application >= 7:
            timing = "last week"
        return (
            f"Subject: Following up on {role} application\n\n"
            f"Hello,\n\n"
            f"I hope you are doing well. I wanted to follow up on my application for the {role} role at {company}, "
            f"which I submitted {timing}. I remain very interested in the opportunity and would appreciate any update "
            f"you can share about the hiring process.\n\n"
            f"Thank you for your time.\n\n"
            f"Best regards"
        )
