from __future__ import annotations

import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any


class ApplicationTracker:
    """SQLite-backed job application tracker."""

    def __init__(self, db_path: str | Path = "data/resume_ai.sqlite3") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def add_application(self, company: str, role: str, date_applied: str, status: str) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO applications(company, role, date_applied, status, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (company, role, date_applied, status, datetime.utcnow().isoformat(timespec="seconds")),
            )
            return int(cursor.lastrowid)

    def list_applications(self) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, company, role, date_applied, status FROM applications ORDER BY date_applied DESC, id DESC"
            ).fetchall()
        items = [dict(row) for row in rows]
        for item in items:
            item["days_since_application"] = self.days_since(item["date_applied"])
        return items

    def days_since(self, date_applied: str) -> int:
        try:
            applied = date.fromisoformat(date_applied)
        except ValueError:
            return 0
        return max(0, (date.today() - applied).days)

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS applications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    company TEXT NOT NULL,
                    role TEXT NOT NULL,
                    date_applied TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
