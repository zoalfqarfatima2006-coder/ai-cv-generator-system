"""Persistence extensions for enhancement data."""
