from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any


class UserTrackingDB:
    """Stores lightweight portfolio features: goals, bookmarked jobs, and activities."""

    def __init__(self, db_path: str | Path = "data/user_tracking.sqlite3") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def add_activity(self, label: str, detail: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO activities(created_at, label, detail) VALUES (?, ?, ?)",
                (datetime.utcnow().isoformat(timespec="seconds"), label, detail),
            )

    def add_goal(self, title: str, target: int) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO goals(created_at, title, target, progress) VALUES (?, ?, ?, 0)",
                (datetime.utcnow().isoformat(timespec="seconds"), title, target),
            )
        self.add_activity("Goal created", title)

    def update_goal_progress(self, goal_id: int, progress: int) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("UPDATE goals SET progress = ? WHERE id = ?", (progress, goal_id))
        self.add_activity("Goal updated", f"Goal #{goal_id} progress set to {progress}")

    def fetch_goals(self) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT id, title, target, progress FROM goals ORDER BY id DESC LIMIT 5").fetchall()
        return [dict(row) for row in rows]

    def fetch_activities(self) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT created_at, label, detail FROM activities ORDER BY id DESC LIMIT 8"
            ).fetchall()
        return [dict(row) for row in rows]

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS goals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    title TEXT NOT NULL,
                    target INTEGER NOT NULL,
                    progress INTEGER NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    label TEXT NOT NULL,
                    detail TEXT NOT NULL
                )
                """
            )
