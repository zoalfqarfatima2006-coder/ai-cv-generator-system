from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any


class EnhancementHistoryDB:
    """Stores score, match, and skill-gap trends without altering the base DB."""

    def __init__(self, db_path: str | Path = "data/enhancement_history.sqlite3") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def save_snapshot(self, candidate_name: str | None, ats_score: int, match_score: int, missing_skills: list[str]) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO trend_snapshots(created_at, candidate_name, ats_score, match_score, missing_skill_count)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(timespec="seconds"),
                    candidate_name or "Unknown",
                    ats_score,
                    match_score,
                    len(missing_skills),
                ),
            )
            return int(cursor.lastrowid)

    def fetch_trends(self, limit: int = 20) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT created_at, candidate_name, ats_score, match_score, missing_skill_count
                FROM trend_snapshots
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return list(reversed([dict(row) for row in rows]))

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trend_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    candidate_name TEXT,
                    ats_score INTEGER,
                    match_score INTEGER,
                    missing_skill_count INTEGER
                )
                """
            )
