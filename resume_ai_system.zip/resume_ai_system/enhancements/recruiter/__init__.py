"""Recruiter and ATS lens analysis."""
