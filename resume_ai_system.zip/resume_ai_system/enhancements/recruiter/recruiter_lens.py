from __future__ import annotations

import html
import re
from dataclasses import dataclass

from backend.models.resume_model import ParsedResume
from backend.parser.skill_extractor import SkillExtractor


@dataclass(slots=True)
class RecruiterLensResult:
    matched_keywords: list[str]
    missing_keywords: list[str]
    red_flags: list[str]
    ats_score: int
    pass_probability: int
    highlighted_resume: str


class RecruiterLens:
    """Simulates how a recruiter or ATS might scan the resume."""

    def __init__(self) -> None:
        self.skill_extractor = SkillExtractor()

    def analyze(self, parsed: ParsedResume, resume_text: str, job_description: str) -> RecruiterLensResult:
        resume_skills = {skill.lower() for skill in parsed.skills}
        jd_skills = {skill.lower() for skill in self.skill_extractor.extract(job_description)}
        matched = sorted(resume_skills & jd_skills)
        missing = sorted(jd_skills - resume_skills)
        red_flags = self._red_flags(parsed, resume_text)
        skill_score = round((len(matched) / len(jd_skills)) * 100) if jd_skills else 45
        ats_score = max(0, min(100, skill_score - len(red_flags) * 8 + (20 if parsed.email and parsed.phone else 0)))
        return RecruiterLensResult(
            matched_keywords=[item.title() for item in matched],
            missing_keywords=[item.title() for item in missing],
            red_flags=red_flags or ["No major recruiter red flags detected."],
            ats_score=ats_score,
            pass_probability=max(0, min(100, round(ats_score * 0.82))),
            highlighted_resume=self.highlight(resume_text, list(matched)),
        )

    def highlight(self, resume_text: str, keywords: list[str]) -> str:
        highlighted = html.escape(resume_text)
        for keyword in sorted(set(keywords), key=len, reverse=True):
            if len(keyword) < 3:
                continue
            highlighted = re.sub(rf"\b({re.escape(html.escape(keyword))})\b", r"<mark>\1</mark>", highlighted, flags=re.I)
        return highlighted

    def _red_flags(self, parsed: ParsedResume, resume_text: str) -> list[str]:
        flags = []
        if not parsed.email:
            flags.append("Missing email address.")
        if not parsed.phone:
            flags.append("Missing phone number.")
        if not parsed.skills:
            flags.append("No detectable skills section.")
        if "experience" not in resume_text.lower():
            flags.append("No clear experience section heading.")
        years = [int(year) for year in re.findall(r"\b(20\d{2}|19\d{2})\b", resume_text)]
        if years and max(years) - min(years) > parsed.experience_years + 3:
            flags.append("Possible employment timeline gap; clarify dates.")
        return flags
