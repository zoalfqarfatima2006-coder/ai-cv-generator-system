from __future__ import annotations

from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume
from backend.providers import get_provider
from backend.utils.text_cleaner import TextCleaner


@dataclass(slots=True)
class RewriteResult:
    mode: str
    rewritten_summary: str
    bullet_suggestions: list[str]


class ResumeRewriter:
    """Offline rewrite assistant that suggests improved wording without changing source files."""

    def __init__(self) -> None:
        self.cleaner = TextCleaner()
        self.provider = get_provider()

    def rewrite_for_job(self, parsed: ParsedResume, match: MatchResult) -> RewriteResult:
        focus = ", ".join((match.matched_skills + match.missing_skills)[:6]) or "the target role"
        summary = (
            f"{parsed.name or 'Candidate'} is a results-focused professional with experience across {focus}. "
            "The resume should emphasize job-aligned projects, measurable outcomes, and tools named in the posting."
        )
        bullets = [
            "Rewrite each major project bullet to include tool, action, result, and metric.",
            "Place the most job-relevant skills in the first third of the Skills section.",
            "Use exact job-description keywords only where they truthfully match your work.",
        ]
        return RewriteResult("Rewrite for Job", summary, bullets)

    def improve_resume(self, parsed: ParsedResume) -> RewriteResult:
        summary = (
            f"{parsed.name or 'Candidate'} should present a sharper profile with a clear title target, "
            "strong technical keywords, and quantified achievements."
        )
        bullets = [
            "Start bullets with action verbs such as Built, Automated, Improved, Led, Reduced, or Delivered.",
            "Add metrics: percentage improvement, time saved, users supported, revenue impact, or accuracy lift.",
            "Group skills into categories so recruiters can scan faster.",
        ]
        return RewriteResult("Improve Resume", summary, bullets)

    def improve_bullets(self, bullets: list[str], job_description: str = "", use_llm: bool = False) -> list[str]:
        """Rewrite bullets with stronger action, scope, and impact language."""
        if use_llm:
            prompt = "Improve these resume bullets for ATS and clarity while preserving facts:\n"
            prompt += "\n".join(f"- {bullet}" for bullet in bullets)
            if job_description:
                prompt += f"\n\nTarget job description:\n{job_description}"
            return [line.strip(" -") for line in self.provider.generate_text(prompt).splitlines() if line.strip()]
        return [self._offline_bullet_rewrite(bullet) for bullet in bullets]

    def quantify_impact(self, bullet: str) -> str:
        """Suggest measurable framing for a bullet that lacks numbers."""
        if any(char.isdigit() for char in bullet):
            return bullet
        return f"{bullet.rstrip('.')} resulting in measurable improvements to speed, quality, cost, or user outcomes."

    def inject_ats_keywords(self, text: str, keywords: list[str]) -> str:
        """Append a truthful keyword reminder section without altering user claims."""
        clean_keywords = [keyword for keyword in keywords if keyword.lower() not in text.lower()]
        if not clean_keywords:
            return text
        return f"{text.rstrip()}\n\nTarget Keywords To Add Where Truthful: {', '.join(clean_keywords[:10])}"

    def inject_keywords(self, text: str, keywords: list[str]) -> str:
        """Backward-compatible public API for keyword injection."""
        return self.inject_ats_keywords(text, keywords)

    def _offline_bullet_rewrite(self, bullet: str) -> str:
        bullet = bullet.strip(" -")
        if not bullet:
            return ""
        if bullet.split()[0].lower() in {"built", "created", "developed", "improved", "led", "automated"}:
            return self.quantify_impact(bullet)
        return self.quantify_impact(f"Improved {bullet[0].lower() + bullet[1:]}")
