"""Resume rewriting helpers."""
