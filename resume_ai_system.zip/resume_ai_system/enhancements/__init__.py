"""Add-on features that extend the base resume analyzer without replacing it."""
