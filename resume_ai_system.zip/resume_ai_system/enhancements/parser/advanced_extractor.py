from __future__ import annotations

import re
from dataclasses import dataclass

from backend.models.resume_model import ParsedResume
from backend.parser.resume_parser import ResumeParser


@dataclass(slots=True)
class AdvancedResumeData:
    name: str | None
    email: str | None
    phone: str | None
    skills: list[str]
    experience_years: float
    college: str | None
    degree: str | None
    designations: list[str]
    company_names: list[str]


class AdvancedResumeExtractor:
    """Adds pyresparser-style fields while reusing the existing parser."""

    DESIGNATION_WORDS = {
        "engineer", "developer", "analyst", "manager", "consultant", "designer",
        "architect", "scientist", "specialist", "intern", "lead", "director",
    }

    def __init__(self, base_parser: ResumeParser | None = None) -> None:
        self.base_parser = base_parser or ResumeParser()

    def extract(self, resume_text: str, parsed: ParsedResume | None = None) -> AdvancedResumeData:
        parsed = parsed or self.base_parser.parse(resume_text)
        return AdvancedResumeData(
            name=parsed.name,
            email=parsed.email,
            phone=parsed.phone,
            skills=parsed.skills,
            experience_years=parsed.experience_years,
            college=self._college(parsed),
            degree=self._degree(parsed),
            designations=self._designations(parsed.raw_text or resume_text),
            company_names=self._companies(parsed.raw_text or resume_text),
        )

    def _college(self, parsed: ParsedResume) -> str | None:
        for item in parsed.education:
            if re.search(r"university|college|institute|school|academy", item, re.I):
                return item
        return None

    def _degree(self, parsed: ParsedResume) -> str | None:
        for item in parsed.education:
            if re.search(r"bachelor|master|phd|mba|b\.?s|m\.?s|btech|mtech|degree", item, re.I):
                return item
        return parsed.education[0] if parsed.education else None

    def _designations(self, text: str) -> list[str]:
        values: list[str] = []
        for line in text.splitlines():
            clean = line.strip(" -|")
            lowered = clean.lower()
            if 3 <= len(clean.split()) <= 8 and any(word in lowered for word in self.DESIGNATION_WORDS):
                values.append(clean)
        return list(dict.fromkeys(values))[:8]

    def _companies(self, text: str) -> list[str]:
        patterns = [
            r"\b(?:at|with|for)\s+([A-Z][A-Za-z0-9&.,' -]{2,40})",
            r"\b([A-Z][A-Za-z0-9&.' -]{2,35})\s+(?:Inc|LLC|Ltd|Limited|Corporation|Corp|Technologies|Solutions)\b",
        ]
        found: list[str] = []
        for pattern in patterns:
            found.extend(match.group(1).strip(" .,") for match in re.finditer(pattern, text))
        cleaned = [value for value in found if " at " not in value.lower() and len(value.split()) <= 5]
        return list(dict.fromkeys(cleaned))[:8]
