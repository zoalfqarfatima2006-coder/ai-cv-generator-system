"""Advanced extraction wrappers."""
