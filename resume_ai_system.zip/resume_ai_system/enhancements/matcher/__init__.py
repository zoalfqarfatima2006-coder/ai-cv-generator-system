"""Enhanced job matching wrappers."""
