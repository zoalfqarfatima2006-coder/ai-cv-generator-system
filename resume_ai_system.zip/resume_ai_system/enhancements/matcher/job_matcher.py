from __future__ import annotations

from dataclasses import dataclass

from backend.matcher.matcher import ResumeMatcher


@dataclass(slots=True)
class EnhancedJobMatch:
    match_score: int
    matched_skills: list[str]
    missing_skills: list[str]
    semantic_similarity: float
    skill_coverage: float


class JobMatcher:
    """Safe wrapper around the existing matcher module."""

    def __init__(self, base_matcher: ResumeMatcher | None = None) -> None:
        self.base_matcher = base_matcher or ResumeMatcher()

    def analyze(self, resume_text: str, job_description: str, resume_skills: list[str] | None = None) -> EnhancedJobMatch:
        result = self.base_matcher.match(resume_text, job_description, resume_skills)
        return EnhancedJobMatch(
            match_score=result.match_percentage,
            matched_skills=result.matched_skills,
            missing_skills=result.missing_skills,
            semantic_similarity=result.semantic_similarity,
            skill_coverage=result.skill_coverage,
        )
