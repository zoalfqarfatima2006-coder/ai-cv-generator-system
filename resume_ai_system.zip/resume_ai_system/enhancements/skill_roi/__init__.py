"""Skill ROI analysis."""
