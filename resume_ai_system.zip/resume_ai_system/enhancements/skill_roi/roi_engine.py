from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class SkillROI:
    skill: str
    job_demand_score: int
    salary_impact_estimate: str
    related_skills: list[str]
    recommendation: str


class SkillROIEngine:
    """Offline static-market skill ROI lookup."""

    def __init__(self, data_path: str | Path = "data/skills_market.json") -> None:
        self.data_path = Path(data_path)

    def analyze(self, target_skill: str) -> SkillROI:
        data = self._load()
        key = target_skill.strip().lower()
        item = data.get(key) or data.get("default", {})
        demand = int(item.get("job_demand_score", 50))
        salary = item.get("salary_impact_estimate", "Moderate impact")
        related = list(item.get("related_skills", []))
        recommendation = item.get("recommendation", f"Build one practical project using {target_skill}.")
        return SkillROI(target_skill.title(), demand, salary, related, recommendation)

    def _load(self) -> dict:
        if not self.data_path.exists():
            return {}
        return json.loads(self.data_path.read_text(encoding="utf-8"))
