from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass(slots=True)
class ProfileExperience:
    title: str
    company: str
    dates: str
    bullets: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ProfileProject:
    name: str
    description: str
    skills: list[str] = field(default_factory=list)
    bullets: list[str] = field(default_factory=list)


@dataclass(slots=True)
class MasterProfile:
    """Structured, API-ready user profile for generating tailored resumes."""

    name: str = ""
    email: str = ""
    phone: str = ""
    summary: str = ""
    skills: list[str] = field(default_factory=list)
    education: list[str] = field(default_factory=list)
    certifications: list[str] = field(default_factory=list)
    experience: list[ProfileExperience] = field(default_factory=list)
    projects: list[ProfileProject] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "MasterProfile":
        experience = [ProfileExperience(**item) for item in payload.get("experience", [])]
        projects = [ProfileProject(**item) for item in payload.get("projects", [])]
        return cls(
            name=payload.get("name", ""),
            email=payload.get("email", ""),
            phone=payload.get("phone", ""),
            summary=payload.get("summary", ""),
            skills=list(payload.get("skills", [])),
            education=list(payload.get("education", [])),
            certifications=list(payload.get("certifications", [])),
            experience=experience,
            projects=projects,
        )
