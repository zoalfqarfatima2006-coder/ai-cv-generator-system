from __future__ import annotations

import io
import json
from pathlib import Path

from backend.providers import get_provider
from backend.utils.text_cleaner import TextCleaner
from enhancements.profile.master_profile import MasterProfile, ProfileExperience, ProfileProject


class ProfileManager:
    """Stores a master profile and generates filtered resumes for a job description."""

    def __init__(self, storage_path: str | Path = "data/master_profile.json") -> None:
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.cleaner = TextCleaner()
        self.provider = get_provider()

    def save(self, profile: MasterProfile) -> None:
        self.storage_path.write_text(json.dumps(profile.to_dict(), indent=2), encoding="utf-8")

    def load(self) -> MasterProfile:
        if not self.storage_path.exists():
            return MasterProfile()
        return MasterProfile.from_dict(json.loads(self.storage_path.read_text(encoding="utf-8")))

    def from_parsed_resume(self, parsed) -> MasterProfile:
        return MasterProfile(
            name=parsed.name or "",
            email=parsed.email or "",
            phone=parsed.phone or "",
            summary=f"{parsed.name or 'Candidate'} with {parsed.experience_years:g} years of detected experience.",
            skills=parsed.skills,
            education=parsed.education,
            experience=[
                ProfileExperience(
                    title="Experience",
                    company="",
                    dates="",
                    bullets=[line.strip(" -") for line in parsed.sections.get("experience", "").splitlines() if line.strip()][:6],
                )
            ],
        )

    def generate_tailored_resume(self, profile: MasterProfile, job_description: str, use_llm: bool = False) -> str:
        keywords = set(self.cleaner.normalize_for_match(job_description).split())
        selected_skills = [skill for skill in profile.skills if self.cleaner.normalize_for_match(skill) in keywords]
        selected_skills = selected_skills or profile.skills[:10]
        projects = self._filter_projects(profile.projects, keywords)
        experiences = self._filter_experience(profile.experience, keywords)

        resume = self._format_resume(profile, selected_skills, experiences, projects)
        if use_llm:
            prompt = f"Rewrite this resume professionally for the job while preserving facts:\n\nJob:\n{job_description}\n\nResume:\n{resume}"
            return self.provider.generate_text(prompt)
        return resume

    def export_pdf(self, resume_text: str) -> bytes:
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            return resume_text.encode("utf-8")

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, title="Tailored Resume")
        styles = getSampleStyleSheet()
        story = [Paragraph("Tailored Resume", styles["Title"]), Spacer(1, 10)]
        for line in resume_text.splitlines():
            story.append(Paragraph(line or " ", styles["Normal"]))
        doc.build(story)
        return buffer.getvalue()

    def _filter_projects(self, projects: list[ProfileProject], keywords: set[str]) -> list[ProfileProject]:
        selected = []
        for project in projects:
            text = self.cleaner.normalize_for_match(" ".join([project.name, project.description, " ".join(project.skills)]))
            if keywords & set(text.split()):
                selected.append(project)
        return selected or projects[:2]

    def _filter_experience(self, experience: list[ProfileExperience], keywords: set[str]) -> list[ProfileExperience]:
        selected = []
        for item in experience:
            text = self.cleaner.normalize_for_match(" ".join([item.title, item.company, " ".join(item.bullets)]))
            bullets = [bullet for bullet in item.bullets if keywords & set(self.cleaner.normalize_for_match(bullet).split())]
            if keywords & set(text.split()):
                selected.append(ProfileExperience(item.title, item.company, item.dates, bullets or item.bullets[:3]))
        return selected or experience[:2]

    def _format_resume(
        self,
        profile: MasterProfile,
        skills: list[str],
        experience: list[ProfileExperience],
        projects: list[ProfileProject],
    ) -> str:
        lines = [profile.name, f"{profile.email} | {profile.phone}".strip(" | "), "", "SUMMARY", profile.summary, "", "SKILLS"]
        lines.append(", ".join(skills))
        lines.extend(["", "EXPERIENCE"])
        for item in experience:
            lines.append(f"{item.title} - {item.company} {item.dates}".strip())
            lines.extend(f"- {bullet}" for bullet in item.bullets[:5])
        lines.extend(["", "PROJECTS"])
        for item in projects:
            lines.append(item.name)
            lines.append(f"- {item.description}")
            lines.extend(f"- {bullet}" for bullet in item.bullets[:3])
        lines.extend(["", "EDUCATION"])
        lines.extend(f"- {item}" for item in profile.education)
        if profile.certifications:
            lines.extend(["", "CERTIFICATIONS"])
            lines.extend(f"- {item}" for item in profile.certifications)
        return "\n".join(line for line in lines if line is not None)
