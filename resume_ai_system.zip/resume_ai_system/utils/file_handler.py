import io
import json
import sqlite3
from dataclasses import asdict, is_dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


class FileHandler:
    """Read uploaded resumes and persist analysis reports locally."""

    def __init__(self, data_dir: str | Path = "data") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "resume_ai.sqlite3"
        self._init_db()

    def extract_text(self, uploaded_file: Any) -> str:
        name = getattr(uploaded_file, "name", "")
        suffix = Path(name).suffix.lower()
        content = uploaded_file.getvalue()
        if suffix == ".pdf":
            return self._extract_pdf(content)
        if suffix == ".docx":
            return self._extract_docx(content)
        raise ValueError("Unsupported file type. Please upload a PDF or DOCX resume.")

    def save_analysis(self, payload: dict[str, Any]) -> int:
        safe_payload = self._jsonable(payload)
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "INSERT INTO analyses(created_at, candidate_name, match_score, ats_score, payload) VALUES (?, ?, ?, ?, ?)",
                (
                    datetime.utcnow().isoformat(timespec="seconds"),
                    safe_payload.get("parsed", {}).get("name") or "Unknown",
                    safe_payload.get("match", {}).get("match_percentage", 0),
                    safe_payload.get("score", {}).get("overall_score", 0),
                    json.dumps(safe_payload),
                ),
            )
            return int(cursor.lastrowid)

    def fetch_recent(self, limit: int = 10) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT id, created_at, candidate_name, match_score, ats_score FROM analyses ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def build_pdf_report(self, payload: dict[str, Any]) -> bytes:
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            return json.dumps(self._jsonable(payload), indent=2).encode("utf-8")

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        story = [Paragraph("AI Resume Intelligence Report", styles["Title"]), Spacer(1, 12)]

        parsed = payload.get("parsed", {})
        match = payload.get("match", {})
        score = payload.get("score", {})
        story.append(Paragraph(f"Candidate: {parsed.get('name') or 'Unknown'}", styles["Heading2"]))
        story.append(Paragraph(f"Match Score: {match.get('match_percentage', 0)}%", styles["Normal"]))
        story.append(Paragraph(f"ATS Score: {score.get('overall_score', 0)}%", styles["Normal"]))
        story.append(Spacer(1, 10))
        story.append(Paragraph("Missing Skills", styles["Heading2"]))
        story.append(Paragraph(", ".join(match.get("missing_skills", [])) or "No major gaps detected.", styles["Normal"]))
        story.append(Paragraph("Suggestions", styles["Heading2"]))
        for suggestion in payload.get("suggestions", []):
            story.append(Paragraph(f"- {suggestion}", styles["Normal"]))
        doc.build(story)
        return buffer.getvalue()

    def _extract_pdf(self, content: bytes) -> str:
        try:
            import pdfplumber
        except ImportError as exc:
            raise RuntimeError("Install pdfplumber to read PDF resumes.") from exc
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)

    def _extract_docx(self, content: bytes) -> str:
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("Install python-docx to read DOCX resumes.") from exc
        document = Document(io.BytesIO(content))
        return "\n".join(paragraph.text for paragraph in document.paragraphs)

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS analyses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    candidate_name TEXT,
                    match_score REAL,
                    ats_score REAL,
                    payload TEXT NOT NULL
                )
                """
            )

    def _jsonable(self, value: Any) -> Any:
        if is_dataclass(value):
            return asdict(value)
        if isinstance(value, dict):
            return {key: self._jsonable(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._jsonable(item) for item in value]
        return value
