from dataclasses import asdict

import streamlit as st

from matcher.matcher import ResumeMatcher
from parser.resume_parser import ResumeParser
from scoring.scorer import ResumeScorer
from suggestions.suggestion_engine import SuggestionEngine
from utils.file_handler import FileHandler
from utils.text_cleaner import TextCleaner


class ResumeDashboard:
    def __init__(self) -> None:
        self.cleaner = TextCleaner()
        self.file_handler = FileHandler("data")
        self.parser = ResumeParser()
        self.matcher = ResumeMatcher()
        self.scorer = ResumeScorer()
        self.suggestions = SuggestionEngine(offline_mode=True)

    def render(self) -> None:
        self._page_config()
        uploaded_file, job_description = self._sidebar()
        st.title("AI Resume Intelligence System")
        st.caption("Offline resume parsing, ATS scoring, job matching, skill gaps, suggestions, reports, and local history.")

        if not uploaded_file:
            self._empty_state()
            self._history()
            return

        try:
            resume_text = self.cleaner.clean(self.file_handler.extract_text(uploaded_file))
        except Exception as exc:
            st.error(str(exc))
            return

        if not job_description.strip():
            st.info("Paste a job description in the sidebar to unlock match scoring and skill-gap analysis.")
            parsed = self.parser.parse(resume_text)
            self._summary(parsed, resume_text)
            return

        self._analysis(resume_text, job_description)

    def _page_config(self) -> None:
        st.set_page_config(page_title="AI Resume Intelligence System", page_icon="AI", layout="wide")
        st.markdown(
            """
            <style>
            .block-container { padding-top: 2rem; }
            mark { background: #fff3a3; color: #111827; padding: 0 0.2rem; border-radius: 0.2rem; }
            [data-testid="stMetricValue"] { font-size: 2.2rem; }
            </style>
            """,
            unsafe_allow_html=True,
        )

    def _sidebar(self):
        with st.sidebar:
            st.header("Inputs")
            uploaded_file = st.file_uploader("Upload resume", type=["pdf", "docx"])
            job_description = st.text_area("Job description", height=260, placeholder="Paste the target job description here...")
            st.divider()
            st.caption("Offline mode is enabled by default. No resume text leaves this machine.")
        return uploaded_file, job_description

    def _empty_state(self) -> None:
        left, right = st.columns([1.2, 1])
        with left:
            st.subheader("Start with a resume upload")
            st.write("Upload a PDF or DOCX resume, paste a job description, and run a full ATS-style analysis.")
        with right:
            st.info("Modules: parser, skill extractor, matcher, scorer, suggestions, dashboard, SQLite storage, PDF report.")

    def _analysis(self, resume_text: str, job_description: str) -> None:
        parsed = self.parser.parse(resume_text)
        match = self.matcher.match(resume_text, job_description, parsed.skills)
        score = self.scorer.score(parsed, match, resume_text)
        suggestions = self.suggestions.generate(parsed, match, score)
        payload = {
            "parsed": asdict(parsed),
            "match": asdict(match),
            "score": asdict(score),
            "suggestions": suggestions,
        }
        self.file_handler.save_analysis(payload)

        top = st.columns(4)
        top[0].metric("Match Score", f"{match.match_percentage}%")
        top[1].metric("ATS Score", f"{score.ats_score}%")
        top[2].metric("Overall Score", f"{score.overall_score}%")
        top[3].metric("Detected Skills", len(parsed.skills))

        self._summary(parsed, resume_text)
        self._skill_gap(match)
        self._scores(score)
        self._suggestions(suggestions, score)
        self._keyword_highlights(resume_text, match.jd_keywords)
        self._download(payload)
        self._history()

    def _summary(self, parsed, resume_text: str) -> None:
        st.subheader("Resume Summary")
        col1, col2 = st.columns([1, 1.4])
        with col1:
            st.write(
                {
                    "name": parsed.name,
                    "email": parsed.email,
                    "phone": parsed.phone,
                    "linkedin": parsed.contact_info.get("linkedin"),
                    "experience_years": parsed.experience_years,
                }
            )
        with col2:
            st.write("Skills")
            st.write(", ".join(parsed.skills) if parsed.skills else "No known skills detected yet.")
            st.write("Education")
            st.write("; ".join(parsed.education) if parsed.education else "No education signals detected.")

    def _skill_gap(self, match) -> None:
        st.subheader("Skill Gap")
        col1, col2 = st.columns(2)
        with col1:
            st.success(", ".join(match.matched_skills) if match.matched_skills else "No direct skill overlap detected.")
        with col2:
            st.warning(", ".join(match.missing_skills) if match.missing_skills else "No major missing skills detected.")

    def _scores(self, score) -> None:
        st.subheader("Section-Wise Scoring")
        st.bar_chart(score.section_scores)
        cols = st.columns(2)
        with cols[0]:
            st.write("Strengths")
            for item in score.strengths:
                st.write(f"- {item}")
        with cols[1]:
            st.write("Risks")
            for item in score.risks or ["No major risks detected."]:
                st.write(f"- {item}")

    def _suggestions(self, suggestions: list[str], score) -> None:
        st.subheader("Smart Suggestions")
        for item in suggestions:
            st.write(f"- {item}")

    def _keyword_highlights(self, resume_text: str, keywords: list[str]) -> None:
        st.subheader("Keyword Highlighting")
        with st.expander("View resume with JD keywords highlighted"):
            highlighted = self.suggestions.highlight_keywords(resume_text, keywords)
            st.markdown(f"<div style='white-space: pre-wrap'>{highlighted}</div>", unsafe_allow_html=True)

    def _download(self, payload: dict) -> None:
        st.subheader("Download Report")
        report = self.file_handler.build_pdf_report(payload)
        st.download_button(
            "Download analysis report",
            report,
            file_name="resume_intelligence_report.pdf",
            mime="application/pdf",
        )

    def _history(self) -> None:
        rows = self.file_handler.fetch_recent()
        if rows:
            st.subheader("Recent Analyses")
            st.dataframe(rows, hide_index=True, use_container_width=True)

