import re
from dataclasses import dataclass, field

from utils.text_cleaner import TextCleaner


DEFAULT_SKILLS = {
    "python", "java", "javascript", "typescript", "c++", "c#", "sql", "html", "css",
    "react", "angular", "vue", "node.js", "express", "django", "flask", "fastapi",
    "spring", "streamlit", "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch",
    "machine learning", "deep learning", "nlp", "computer vision", "data analysis",
    "data visualization", "power bi", "tableau", "excel", "git", "github", "docker",
    "kubernetes", "aws", "azure", "gcp", "linux", "bash", "rest api", "graphql",
    "postgresql", "mysql", "sqlite", "mongodb", "redis", "etl", "airflow", "spark",
    "hadoop", "ci/cd", "jenkins", "terraform", "agile", "scrum", "jira", "figma",
    "project management", "leadership", "communication", "problem solving",
    "stakeholder management", "salesforce", "crm", "seo", "content strategy",
    "financial modeling", "statistics", "a/b testing", "product management",
}


@dataclass
class SkillExtractor:
    skills: set[str] = field(default_factory=lambda: set(DEFAULT_SKILLS))
    cleaner: TextCleaner = field(default_factory=TextCleaner)

    def extract(self, text: str) -> list[str]:
        normalized = f" {self.cleaner.normalize_for_match(text)} "
        found = []
        for skill in sorted(self.skills, key=len, reverse=True):
            pattern = r"(?<![a-z0-9+#.])" + re.escape(skill.lower()) + r"(?![a-z0-9+#.])"
            if re.search(pattern, normalized):
                found.append(self._display(skill))
        return sorted(set(found), key=str.lower)

    def extract_weighted_keywords(self, text: str, limit: int = 25) -> list[str]:
        normalized = self.cleaner.normalize_for_match(text)
        words = re.findall(r"\b[a-z][a-z0-9+#.-]{2,}\b", normalized)
        stop = {
            "and", "the", "with", "for", "you", "our", "are", "will", "from", "this",
            "that", "have", "has", "your", "using", "work", "team", "role", "job",
            "experience", "skills", "ability", "required", "preferred",
        }
        counts: dict[str, int] = {}
        for word in words:
            if word not in stop:
                counts[word] = counts.get(word, 0) + 1
        return [word for word, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]]

    def _display(self, skill: str) -> str:
        aliases = {"sql": "SQL", "aws": "AWS", "gcp": "GCP", "nlp": "NLP", "ci/cd": "CI/CD"}
        return aliases.get(skill.lower(), skill.title())

