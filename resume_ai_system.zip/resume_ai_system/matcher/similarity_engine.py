import math
import re
from collections import Counter
from dataclasses import dataclass, field

from utils.text_cleaner import TextCleaner


@dataclass
class SimilarityEngine:
    cleaner: TextCleaner = field(default_factory=TextCleaner)

    def calculate(self, resume_text: str, job_description: str) -> float:
        resume_tokens = self._tokens(resume_text)
        jd_tokens = self._tokens(job_description)
        if not resume_tokens or not jd_tokens:
            return 0.0
        resume_tf = Counter(resume_tokens)
        jd_tf = Counter(jd_tokens)
        vocabulary = set(resume_tf) | set(jd_tf)
        return self._cosine(
            [self._tfidf(term, resume_tf, jd_tf) for term in vocabulary],
            [self._tfidf(term, jd_tf, resume_tf) for term in vocabulary],
        )

    def _tokens(self, text: str) -> list[str]:
        normalized = self.cleaner.normalize_for_match(text)
        stop = {"the", "and", "for", "with", "you", "are", "will", "this", "that", "from", "our", "your"}
        return [token for token in re.findall(r"\b[a-z][a-z0-9+#.-]{2,}\b", normalized) if token not in stop]

    def _tfidf(self, term: str, doc: Counter, other: Counter) -> float:
        tf = doc.get(term, 0)
        docs_with_term = int(term in doc) + int(term in other)
        idf = math.log((2 + 1) / (docs_with_term + 1)) + 1
        return tf * idf

    def _cosine(self, left: list[float], right: list[float]) -> float:
        dot = sum(a * b for a, b in zip(left, right))
        left_norm = math.sqrt(sum(a * a for a in left))
        right_norm = math.sqrt(sum(b * b for b in right))
        if not left_norm or not right_norm:
            return 0.0
        return round(dot / (left_norm * right_norm), 4)

