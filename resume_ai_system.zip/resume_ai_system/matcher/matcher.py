from dataclasses import dataclass, field

from matcher.similarity_engine import SimilarityEngine
from parser.skill_extractor import SkillExtractor


@dataclass
class MatchResult:
    match_percentage: int
    semantic_similarity: float
    matched_skills: list[str]
    missing_skills: list[str]
    jd_keywords: list[str]


@dataclass
class ResumeMatcher:
    skill_extractor: SkillExtractor = field(default_factory=SkillExtractor)
    similarity_engine: SimilarityEngine = field(default_factory=SimilarityEngine)

    def match(self, resume_text: str, job_description: str, resume_skills: list[str] | None = None) -> MatchResult:
        resume_skill_set = {skill.lower() for skill in (resume_skills or self.skill_extractor.extract(resume_text))}
        jd_skills = self.skill_extractor.extract(job_description)
        jd_skill_set = {skill.lower() for skill in jd_skills}
        matched = sorted(jd_skill_set & resume_skill_set)
        missing = sorted(jd_skill_set - resume_skill_set)
        semantic = self.similarity_engine.calculate(resume_text, job_description)
        skill_coverage = len(matched) / len(jd_skill_set) if jd_skill_set else 0
        combined = (semantic * 0.65) + (skill_coverage * 0.35)
        return MatchResult(
            match_percentage=max(0, min(100, round(combined * 100))),
            semantic_similarity=semantic,
            matched_skills=[skill.title() for skill in matched],
            missing_skills=[skill.title() for skill in missing],
            jd_keywords=self.skill_extractor.extract_weighted_keywords(job_description),
        )

