from dataclasses import dataclass

from matcher.matcher import MatchResult
from parser.resume_parser import ParsedResume


@dataclass
class ResumeScore:
    overall_score: int
    ats_score: int
    section_scores: dict[str, int]
    strengths: list[str]
    risks: list[str]


class ResumeScorer:
    def score(self, parsed: ParsedResume, match: MatchResult, resume_text: str) -> ResumeScore:
        contact = self._score_contact(parsed)
        skills = min(100, len(parsed.skills) * 8)
        experience = min(100, int(parsed.experience_years * 14)) if parsed.experience_years else 35
        education = 85 if parsed.education else 35
        keywords = match.match_percentage
        sections = {
            "contact": contact,
            "skills": skills,
            "experience": experience,
            "education": education,
            "job_keywords": keywords,
            "format": self._score_format(resume_text),
        }
        ats = round(sections["contact"] * 0.15 + sections["skills"] * 0.2 + sections["experience"] * 0.2 + sections["job_keywords"] * 0.35 + sections["format"] * 0.1)
        overall = round(ats * 0.7 + match.match_percentage * 0.3)
        strengths = self._strengths(parsed, match, sections)
        risks = self._risks(parsed, match, sections)
        return ResumeScore(overall, ats, sections, strengths, risks)

    def _score_contact(self, parsed: ParsedResume) -> int:
        score = 20
        score += 30 if parsed.name else 0
        score += 25 if parsed.email else 0
        score += 15 if parsed.phone else 0
        score += 10 if parsed.contact_info.get("linkedin") else 0
        return min(100, score)

    def _score_format(self, text: str) -> int:
        score = 55
        lowered = text.lower()
        for section in ("experience", "education", "skills"):
            score += 10 if section in lowered else 0
        score += 10 if any(marker in text for marker in ("-", "*", "•")) else 0
        score += 5 if len(text.split()) >= 250 else 0
        return min(100, score)

    def _strengths(self, parsed: ParsedResume, match: MatchResult, sections: dict[str, int]) -> list[str]:
        strengths = []
        if sections["contact"] >= 80:
            strengths.append("Contact details are complete and easy to parse.")
        if len(parsed.skills) >= 8:
            strengths.append("Skills section contains a healthy range of detectable capabilities.")
        if match.matched_skills:
            strengths.append(f"Strong overlap with job skills: {', '.join(match.matched_skills[:6])}.")
        return strengths or ["The resume has enough text for baseline ATS analysis."]

    def _risks(self, parsed: ParsedResume, match: MatchResult, sections: dict[str, int]) -> list[str]:
        risks = []
        if sections["contact"] < 75:
            risks.append("Contact information may be incomplete or hard for an ATS to extract.")
        if sections["experience"] < 50:
            risks.append("Experience signals are thin; add dates, roles, and measurable outcomes.")
        if match.missing_skills:
            risks.append(f"Missing job-critical skills: {', '.join(match.missing_skills[:8])}.")
        return risks

