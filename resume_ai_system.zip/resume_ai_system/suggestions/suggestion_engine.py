from dataclasses import dataclass

from matcher.matcher import MatchResult
from parser.resume_parser import ParsedResume
from scoring.scorer import ResumeScore


@dataclass
class SuggestionEngine:
    offline_mode: bool = True

    def generate(self, parsed: ParsedResume, match: MatchResult, score: ResumeScore) -> list[str]:
        suggestions: list[str] = []
        if match.missing_skills:
            suggestions.append(f"Add evidence for these JD skills where truthful: {', '.join(match.missing_skills[:8])}.")
        if score.section_scores.get("experience", 0) < 70:
            suggestions.append("Rewrite experience bullets with action verb + scope + measurable result.")
        if score.section_scores.get("format", 0) < 80:
            suggestions.append("Use standard section headers such as Skills, Experience, Education, and Projects.")
        if score.section_scores.get("contact", 0) < 90:
            suggestions.append("Place name, email, phone, and LinkedIn/GitHub in the top resume header.")
        if match.match_percentage < 70:
            suggestions.append("Mirror the job description language for your strongest matching projects and responsibilities.")
        if not parsed.education:
            suggestions.append("Add an education or certification section so screeners can classify credentials.")
        suggestions.append("Keep the resume ATS-friendly: simple headings, no tables for core content, and keyword-rich bullets.")
        return suggestions

    def highlight_keywords(self, text: str, keywords: list[str]) -> str:
        highlighted = text
        for keyword in sorted(set(keywords), key=len, reverse=True)[:30]:
            if len(keyword) < 3:
                continue
            highlighted = self._replace_case_insensitive(highlighted, keyword)
        return highlighted

    def _replace_case_insensitive(self, text: str, keyword: str) -> str:
        import re

        return re.sub(
            rf"\b({re.escape(keyword)})\b",
            r"<mark>\1</mark>",
            text,
            flags=re.I,
        )
