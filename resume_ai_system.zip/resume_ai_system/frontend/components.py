from __future__ import annotations

import html
from pathlib import Path
from typing import Iterable

import streamlit as st


def load_css(path: str | Path = "frontend/styles.css") -> None:
    css_path = Path(path)
    if css_path.exists():
        st.markdown(f"<style>{css_path.read_text(encoding='utf-8')}</style>", unsafe_allow_html=True)


def header(title: str, subtitle: str) -> None:
    st.markdown(f"<div class='hero-title'>{html.escape(title)}</div>", unsafe_allow_html=True)
    st.markdown(f"<div class='hero-subtitle'>{html.escape(subtitle)}</div>", unsafe_allow_html=True)


def metric_card(label: str, value: str, accent: str = "#2563eb") -> None:
    st.markdown(
        f"""
        <div class="metric-card" style="border-top: 4px solid {accent};">
            <div class="metric-label">{html.escape(label)}</div>
            <div class="metric-value">{html.escape(value)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def pills(items: Iterable[str], style: str) -> None:
    values = list(items)
    if not values:
        st.caption("No items detected.")
        return
    css_class = "pill-good" if style == "good" else "pill-bad"
    markup = "".join(f"<span class='pill {css_class}'>{html.escape(item)}</span>" for item in values)
    st.markdown(markup, unsafe_allow_html=True)


def suggestion_card(text: str) -> None:
    st.markdown(f"<div class='suggestion-card'>{html.escape(text)}</div>", unsafe_allow_html=True)


def dark_panel(title: str, body: str) -> None:
    st.markdown(
        f"""
        <div class="dark-panel">
            <strong>{html.escape(title)}</strong>
            <div class="small-muted">{html.escape(body)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
