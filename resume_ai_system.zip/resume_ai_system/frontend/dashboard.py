from __future__ import annotations

import pandas as pd
import streamlit as st

from backend.database.db import ResumeDatabase
from backend.matcher.matcher import ResumeMatcher
from backend.models.resume_model import AnalysisReport
from backend.parser.resume_parser import ResumeParser
from backend.scoring.scorer import ResumeScorer
from backend.suggestions.suggestion_engine import SuggestionEngine
from backend.utils.file_handler import FileHandler
from backend.utils.text_cleaner import TextCleaner
from enhancements.ats.ats_engine import ATSEngine
from enhancements.cover_letter.cover_letter_generator import CoverLetterGenerator
from enhancements.dashboard.progress_dashboard import ProgressDashboardService
from enhancements.database.history_db import EnhancementHistoryDB
from enhancements.interview.interview_prep import InterviewPrepGenerator
from enhancements.matcher.job_matcher import JobMatcher
from enhancements.parser.advanced_extractor import AdvancedResumeExtractor
from enhancements.profile.master_profile import MasterProfile, ProfileExperience, ProfileProject
from enhancements.profile.profile_manager import ProfileManager
from enhancements.recruiter.recruiter_lens import RecruiterLens
from enhancements.recommendations.job_recommender import JobRecommendationEngine
from enhancements.recommendations.learning_path import LearningPathEngine
from enhancements.rewriter.resume_rewriter import ResumeRewriter
from enhancements.skill_roi.roi_engine import SkillROIEngine
from enhancements.tracker.application_tracker import ApplicationTracker
from enhancements.tracker.followup_generator import FollowUpGenerator
from enhancements.database.user_tracking_db import UserTrackingDB
from frontend.components import header, load_css, metric_card, pills, suggestion_card


class ResumeDashboard:
    STEPS = [
        "01 Upload Resume",
        "02 Resume Analysis",
        "03 Job Matcher",
        "04 Suggestions",
        "05 Cover Letter",
        "06 Interview Prep",
        "07 Dashboard",
        "08 Resume Generator",
        "09 Resume Rewriter",
        "10 Application Tracker",
        "11 Recruiter Lens",
        "12 Skill ROI",
    ]
    COMPACT_STEPS = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
    DAILY_TIPS = [
        "Customize the top third of your resume for every role.",
        "Use one metric in every important project bullet.",
        "Mirror job keywords only when they truthfully describe your work.",
        "Prepare one STAR story for leadership, conflict, failure, and impact.",
    ]

    def __init__(self) -> None:
        self.cleaner = TextCleaner()
        self.file_handler = FileHandler()
        self.database = ResumeDatabase("data/resume_ai.sqlite3")
        self.parser = ResumeParser()
        self.matcher = ResumeMatcher()
        self.scorer = ResumeScorer()
        self.suggestions = SuggestionEngine(offline_mode=True)
        self.job_matcher = JobMatcher(self.matcher)
        self.ats_engine = ATSEngine()
        self.advanced_extractor = AdvancedResumeExtractor(self.parser)
        self.cover_letters = CoverLetterGenerator()
        self.interview_prep = InterviewPrepGenerator()
        self.enhancement_history = EnhancementHistoryDB("data/enhancement_history.sqlite3")
        self.progress_dashboard = ProgressDashboardService(self.enhancement_history)
        self.job_recommender = JobRecommendationEngine("data/jobs.json")
        self.learning_paths = LearningPathEngine()
        self.user_tracking = UserTrackingDB("data/user_tracking.sqlite3")
        self.profile_manager = ProfileManager()
        self.rewriter = ResumeRewriter()
        self.application_tracker = ApplicationTracker("data/resume_ai.sqlite3")
        self.followups = FollowUpGenerator()
        self.recruiter_lens = RecruiterLens()
        self.skill_roi = SkillROIEngine("data/skills_market.json")

    def render(self) -> None:
        st.set_page_config(page_title="AI Resume Intelligence System", page_icon="AI", layout="wide")
        load_css()
        self._init_state()
        self._apply_theme()
        selected_step = self._sidebar()

        header(
            "AI Resume Intelligence System",
            "A guided career assistant for resume intelligence, job matching, preparation, and progress tracking.",
        )

        routes = {
            self.STEPS[0]: self.show_upload,
            self.STEPS[1]: self.show_analysis,
            self.STEPS[2]: self.show_matcher,
            self.STEPS[3]: self.show_suggestions,
            self.STEPS[4]: self.show_cover_letter,
            self.STEPS[5]: self.show_interview_prep,
            self.STEPS[6]: self.show_dashboard,
            self.STEPS[7]: self.show_generator,
            self.STEPS[8]: self.show_rewriter,
            self.STEPS[9]: self.show_tracker,
            self.STEPS[10]: self.show_recruiter,
            self.STEPS[11]: self.show_skill_roi,
        }
        routes[selected_step]()

    def _init_state(self) -> None:
        defaults = {
            "current_step": self.STEPS[0],
            "resume_uploaded": False,
            "uploaded_name": None,
            "resume_text": "",
            "parsed_resume": None,
            "advanced_data": None,
            "job_description": "",
            "analysis_report": None,
            "ats_analysis": None,
            "cover_letter": "",
            "generated_resume": "",
            "rewritten_resume": "",
            "recruiter_feedback": None,
            "theme": "Dark",
            "compact_sidebar": False,
        }
        for key, value in defaults.items():
            st.session_state.setdefault(key, value)

    def _sidebar(self) -> str:
        with st.sidebar:
            st.markdown("### CareerOS")
            st.caption("Guided assistant workspace")
            st.session_state.theme = st.toggle("Light mode", value=st.session_state.theme == "Light", help="Switch dashboard theme.")
            st.session_state.theme = "Light" if st.session_state.theme else "Dark"
            st.session_state.compact_sidebar = st.toggle(
                "Compact menu",
                value=st.session_state.compact_sidebar,
                help="Use a smaller sidebar menu.",
            )
            current = st.session_state.get("current_step", self.STEPS[0])
            labels = self.COMPACT_STEPS if st.session_state.compact_sidebar else self.STEPS
            selected_label = st.radio(
                "Navigation",
                labels,
                index=self.STEPS.index(current),
                label_visibility="collapsed",
            )
            selected = self.STEPS[labels.index(selected_label)]
            st.session_state.current_step = selected
            st.divider()
            if st.session_state.resume_uploaded:
                st.success(f"Resume ready: {st.session_state.uploaded_name}")
            else:
                st.info("Upload a resume to unlock the flow.")
            st.markdown("**Daily smart tip**")
            st.caption(self.DAILY_TIPS[len(st.session_state.current_step) % len(self.DAILY_TIPS)])
            st.caption("Offline mode is enabled. Your resume stays on this machine.")
        return selected

    def show_upload(self) -> None:
        st.markdown("<div class='guided-card upload-card'>", unsafe_allow_html=True)
        st.markdown("## Upload your resume to begin analysis")
        st.write("Use a PDF or DOCX file. After upload, the next steps will unlock automatically.")
        uploaded_file = st.file_uploader("Upload resume", type=["pdf", "docx"], label_visibility="collapsed")
        st.markdown("</div>", unsafe_allow_html=True)

        if uploaded_file:
            try:
                resume_text = self.cleaner.clean(self.file_handler.extract_text(uploaded_file))
                parsed = self.parser.parse(resume_text)
                st.session_state.resume_uploaded = True
                st.session_state.uploaded_name = uploaded_file.name
                st.session_state.resume_text = resume_text
                st.session_state.parsed_resume = parsed
                st.session_state.advanced_data = self.advanced_extractor.extract(resume_text, parsed)
                self.user_tracking.add_activity("Resume uploaded", uploaded_file.name)
                st.success("Resume uploaded and analyzed successfully.")
                if st.button("Continue to Resume Analysis", type="primary"):
                    self._go_to(self.STEPS[1])
            except Exception as exc:
                st.error(str(exc))

    def show_analysis(self) -> None:
        if not self._require_resume():
            return

        parsed = st.session_state.parsed_resume
        st.subheader("Resume Analysis")
        st.caption("A clean snapshot of the extracted resume details.")
        col1, col2 = st.columns([0.9, 1.3])
        with col1:
            metric_card("Candidate", parsed.name or "Unknown", "#df2bd6")
            metric_card("Experience", f"{parsed.experience_years:g} years", "#21b7e8")
        with col2:
            st.markdown("### Skills")
            pills(parsed.skills, "good")
            st.markdown("### Education")
            st.write("; ".join(parsed.education) if parsed.education else "No education signals detected.")

        advanced = st.session_state.advanced_data
        with st.expander("View extracted contact and profile details"):
            st.write(
                {
                    "email": parsed.email or "Not found",
                    "phone": parsed.phone or "Not found",
                    "college": advanced.college or "Not found",
                    "degree": advanced.degree or "Not found",
                    "designations": advanced.designations,
                    "companies": advanced.company_names,
                }
            )
        if st.button("Continue to Job Matcher", type="primary"):
            self._go_to(self.STEPS[2])

    def show_matcher(self) -> None:
        if not self._require_resume():
            return

        st.subheader("Job Matcher")
        st.caption("Paste one job description, then analyze how well this resume fits.")
        job_description = st.text_area(
            "Job Description",
            value=st.session_state.job_description,
            height=230,
            placeholder="Paste the target job description here...",
        )
        st.session_state.job_description = job_description

        if st.button("Analyze Match", type="primary", disabled=not job_description.strip()):
            report = self._build_report(st.session_state.resume_text, job_description)
            st.session_state.analysis_report = report
            st.session_state.ats_analysis = self.ats_engine.analyze(report.parsed, report.match, report.score)
            self.database.save_analysis(report.as_dict())
            self.enhancement_history.save_snapshot(
                report.parsed.name,
                report.score.ats_score,
                report.match.match_percentage,
                report.match.missing_skills,
            )
            self.user_tracking.add_activity("Job match analyzed", f"Match score: {report.match.match_percentage}%")
            st.success("Match analysis complete.")

        report = st.session_state.analysis_report
        if report:
            match = report.match
            col1, col2 = st.columns([0.7, 1.3])
            with col1:
                metric_card("Match Score", f"{match.match_percentage}%", "#22d3a6" if match.match_percentage >= 70 else "#ff4d86")
                st.progress(match.match_percentage / 100)
            with col2:
                st.markdown("### Matched Skills")
                pills(match.matched_skills, "good")
                st.markdown("### Missing Skills")
                pills(match.missing_skills, "bad")
            if st.button("Continue to Suggestions", type="primary"):
                self._go_to(self.STEPS[3])

        self._job_recommendations()

    def show_suggestions(self) -> None:
        if not self._require_match():
            return

        report = st.session_state.analysis_report
        ats = st.session_state.ats_analysis
        st.subheader("Suggestions")
        st.caption("Focused recommendations only. Start with the quick wins.")

        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("### Quick Wins")
            for item in report.suggestions[:4]:
                suggestion_card(item)
        with col2:
            st.markdown("### Red Flags")
            for item in ats.red_flags:
                st.error(item)
        with col3:
            st.markdown("### Improvements")
            for item in ats.improvements:
                st.info(item)

        resources = self.learning_paths.build(report.match.missing_skills)
        if resources:
            st.markdown("### Learning Path")
            for item in resources:
                suggestion_card(f"{item.skill}: {item.recommendation}")

        with st.expander("Keyword highlights"):
            highlighted = self.suggestions.highlight_keywords(st.session_state.resume_text, report.match.jd_keywords)
            st.markdown(f"<div style='white-space: pre-wrap'>{highlighted}</div>", unsafe_allow_html=True)

    def show_cover_letter(self) -> None:
        if not self._require_match():
            return

        report = st.session_state.analysis_report
        st.subheader("Cover Letter")
        st.caption("Generate a job-specific cover letter from the resume and job description.")
        tone = st.selectbox("Tone", ["Professional", "Formal", "Enthusiastic"])
        if st.button("Generate Cover Letter", type="primary"):
            st.session_state.cover_letter = self.cover_letters.generate(
                report.parsed,
                st.session_state.job_description,
                report.match,
                tone,
            )
            self.user_tracking.add_activity("Cover letter generated", f"Tone: {tone}")
            if st.session_state.cover_letter:
                st.text_area("Generated cover letter", value=st.session_state.cover_letter, height=300)

    def show_interview_prep(self) -> None:
        if not self._require_match():
            return

        report = st.session_state.analysis_report
        st.subheader("Interview Prep")
        st.caption("Use these questions to prepare concise, evidence-backed answers.")
        for item in self.interview_prep.generate(report.parsed, report.match):
            with st.expander(f"{item.category}: {item.question}"):
                st.markdown(f"**Why asked:** {item.why_asked}")
                st.markdown(f"**Ideal answer structure:** {item.ideal_answer_structure}")
                st.markdown(f"**Common mistake:** {item.common_mistake}")

    def show_dashboard(self) -> None:
        if not self._require_match():
            return

        report = st.session_state.analysis_report
        ats = st.session_state.ats_analysis
        st.subheader("Final Dashboard")
        st.caption("Summary view only: ATS score, match score, interview probability, and trends.")

        col1, col2, col3 = st.columns(3)
        with col1:
            metric_card("ATS Score", f"{report.score.ats_score}%", "#21b7e8")
            st.progress(report.score.ats_score / 100)
        with col2:
            metric_card("Match Score", f"{report.match.match_percentage}%", "#22d3a6")
            st.progress(report.match.match_percentage / 100)
        with col3:
            metric_card("Interview Probability", f"{ats.interview_probability}%", "#df2bd6")
            st.progress(ats.interview_probability / 100)

        trend_df = self.progress_dashboard.trend_frame()
        if trend_df.empty:
            st.info("No saved trend data yet. Run a match analysis to start tracking progress.")
        else:
            st.markdown("### Trends")
            chart_df = trend_df[["created_at", "ats_score", "match_score", "missing_skill_count"]]
            st.line_chart(chart_df, x="created_at", y=["ats_score", "match_score", "missing_skill_count"], use_container_width=True)
            with st.expander("Recent analysis history"):
                st.dataframe(trend_df, hide_index=True, use_container_width=True)
        self._goals_and_activity()

    def show_generator(self) -> None:
        if not self._require_resume():
            return

        parsed = st.session_state.parsed_resume
        st.subheader("Resume Generator")
        st.caption("Build a master profile, then generate a job-targeted resume offline or with an optional provider.")

        saved_profile = self.profile_manager.load()
        base_profile = saved_profile if saved_profile.name else self.profile_manager.from_parsed_resume(parsed)
        with st.form("master_profile_form"):
            col1, col2 = st.columns(2)
            with col1:
                name = st.text_input("Name", value=base_profile.name)
                email = st.text_input("Email", value=base_profile.email)
                phone = st.text_input("Phone", value=base_profile.phone)
            with col2:
                skills_text = st.text_area("Skills", value=", ".join(base_profile.skills), height=100)
                education_text = st.text_area("Education", value="\n".join(base_profile.education), height=100)
            summary = st.text_area("Professional Summary", value=base_profile.summary, height=90)
            experience_text = st.text_area(
                "Experience Bullets",
                value="\n".join(base_profile.experience[0].bullets if base_profile.experience else []),
                height=130,
            )
            projects_text = st.text_area(
                "Projects",
                value="\n".join(project.name for project in base_profile.projects),
                height=90,
                placeholder="One project per line",
            )
            job_description = st.text_area(
                "Target Job Description",
                value=st.session_state.job_description,
                height=170,
            )
            use_llm = st.checkbox("Use configured LLM provider", value=False)
            submitted = st.form_submit_button("Generate Tailored Resume", type="primary")

        if submitted:
            profile = MasterProfile(
                name=name,
                email=email,
                phone=phone,
                summary=summary,
                skills=[item.strip() for item in skills_text.split(",") if item.strip()],
                education=[item.strip() for item in education_text.splitlines() if item.strip()],
                experience=[
                    ProfileExperience(
                        title="Experience",
                        company="",
                        dates="",
                        bullets=[item.strip(" -") for item in experience_text.splitlines() if item.strip()],
                    )
                ],
                projects=[
                    ProfileProject(name=item.strip(), description=item.strip(), skills=[], bullets=[])
                    for item in projects_text.splitlines()
                    if item.strip()
                ],
            )
            self.profile_manager.save(profile)
            profile_id = self.database.save_master_profile(profile.name, profile.to_dict())
            st.session_state.job_description = job_description
            st.session_state.generated_resume = self.profile_manager.generate_tailored_resume(profile, job_description, use_llm)
            self.database.save_resume_version(profile_id, "Tailored Resume", st.session_state.generated_resume)
            self.user_tracking.add_activity("Tailored resume generated", profile.name or "Master profile")
            st.success("Tailored resume generated and saved.")

        if st.session_state.generated_resume:
            st.text_area("Generated Resume", value=st.session_state.generated_resume, height=360)
            st.download_button(
                "Download Resume PDF",
                data=self.file_handler.build_resume_export(st.session_state.generated_resume),
                file_name="tailored_resume.pdf",
                mime="application/pdf",
            )

    def show_rewriter(self) -> None:
        if not self._require_resume():
            return

        parsed = st.session_state.parsed_resume
        report = st.session_state.analysis_report
        st.subheader("Resume Rewriter")
        st.caption("Hybrid rewriting support: offline templates by default, optional provider when enabled.")

        source = parsed.sections.get("experience", st.session_state.resume_text)
        bullets = [line.strip(" -") for line in source.splitlines() if line.strip()][:8]
        job_description = st.text_area("Target Job Description", value=st.session_state.job_description, height=160)
        use_llm = st.checkbox("Use configured LLM provider", value=False, key="rewriter_llm")
        if st.button("Improve Bullets", type="primary"):
            improved = self.rewriter.improve_bullets(bullets, job_description, use_llm)
            keywords = report.match.missing_skills if report else []
            st.session_state.rewritten_resume = self.rewriter.inject_keywords("\n".join(f"- {item}" for item in improved), keywords)
            self.user_tracking.add_activity("Resume bullets rewritten", f"{len(improved)} bullets")

        if st.session_state.rewritten_resume:
            st.text_area("Rewritten Suggestions", value=st.session_state.rewritten_resume, height=280)
            if report:
                st.download_button(
                    "Download Full Analysis PDF",
                    data=self.file_handler.build_full_analysis_report(report.as_dict(), st.session_state.rewritten_resume),
                    file_name="full_resume_analysis.pdf",
                    mime="application/pdf",
                )

    def show_tracker(self) -> None:
        st.subheader("Application Tracker")
        st.caption("Track applications locally and generate follow-ups for the 7- and 14-day windows.")

        with st.form("application_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                company = st.text_input("Company")
                role = st.text_input("Role")
            with col2:
                date_applied = st.date_input("Date Applied")
                status = st.selectbox("Status", ["Applied", "Interview", "Assessment", "Offer", "Rejected", "Closed"])
            submitted = st.form_submit_button("Add Application", type="primary")
        if submitted and company.strip() and role.strip():
            self.application_tracker.add_application(company.strip(), role.strip(), date_applied.isoformat(), status)
            self.user_tracking.add_activity("Application tracked", f"{role.strip()} at {company.strip()}")
            st.success("Application added.")

        applications = self.application_tracker.list_applications()
        if not applications:
            st.info("No applications tracked yet.")
            return
        st.dataframe(pd.DataFrame(applications), hide_index=True, use_container_width=True)
        labels = [f"{item['company']} - {item['role']} ({item['days_since_application']} days)" for item in applications]
        selected = st.selectbox("Generate Follow-Up", labels)
        item = applications[labels.index(selected)]
        st.text_area(
            "Follow-up Email",
            value=self.followups.generate(item["company"], item["role"], item["days_since_application"]),
            height=220,
        )

    def show_recruiter(self) -> None:
        if not self._require_resume():
            return

        st.subheader("Recruiter Lens")
        st.caption("See the resume through a recruiter and ATS-style keyword screen.")
        job_description = st.text_area("Job Description", value=st.session_state.job_description, height=200)
        if st.button("Run Recruiter Lens", type="primary", disabled=not job_description.strip()):
            result = self.recruiter_lens.analyze(st.session_state.parsed_resume, st.session_state.resume_text, job_description)
            st.session_state.recruiter_feedback = {
                "matched_keywords": result.matched_keywords,
                "missing_keywords": result.missing_keywords,
                "red_flags": result.red_flags,
                "ats_score": result.ats_score,
                "pass_probability": result.pass_probability,
                "highlighted_resume": result.highlighted_resume,
            }
            st.session_state.job_description = job_description
            self.user_tracking.add_activity("Recruiter lens completed", f"ATS simulation: {result.ats_score}%")

        feedback = st.session_state.recruiter_feedback
        if feedback:
            col1, col2 = st.columns(2)
            with col1:
                metric_card("ATS Simulation", f"{feedback['ats_score']}%", "#21b7e8")
                metric_card("Pass Probability", f"{feedback['pass_probability']}%", "#22d3a6")
            with col2:
                st.markdown("### Red Flags")
                for flag in feedback["red_flags"]:
                    st.warning(flag)
            st.markdown("### Matched Keywords")
            pills(feedback["matched_keywords"], "good")
            st.markdown("### Missing Keywords")
            pills(feedback["missing_keywords"], "bad")
            with st.expander("Highlighted Resume"):
                st.markdown(f"<div style='white-space: pre-wrap'>{feedback['highlighted_resume']}</div>", unsafe_allow_html=True)
            st.download_button(
                "Download Recruiter Feedback PDF",
                data=self.file_handler.build_recruiter_feedback_export(feedback),
                file_name="recruiter_feedback.pdf",
                mime="application/pdf",
            )

    def show_skill_roi(self) -> None:
        st.subheader("Skill ROI")
        st.caption("Offline market signal lookup from a local JSON dataset.")
        skill = st.text_input("Skill", placeholder="Python, SQL, AWS, React")
        if st.button("Analyze Skill ROI", type="primary", disabled=not skill.strip()):
            result = self.skill_roi.analyze(skill)
            payload = {
                "skill": result.skill,
                "job_demand_score": result.job_demand_score,
                "salary_impact_estimate": result.salary_impact_estimate,
                "related_skills": result.related_skills,
                "recommendation": result.recommendation,
            }
            self.database.save_skill_roi_log(result.skill, result.job_demand_score, payload)
            metric_card("Demand Score", f"{result.job_demand_score}/100", "#df2bd6")
            st.progress(result.job_demand_score / 100)
            st.markdown("### Salary Impact")
            st.info(result.salary_impact_estimate)
            st.markdown("### Related Skills")
            pills(result.related_skills, "good")
            suggestion_card(result.recommendation)

    def _build_report(self, resume_text: str, job_description: str) -> AnalysisReport:
        parsed = st.session_state.parsed_resume or self.parser.parse(resume_text)
        match = self.matcher.match(resume_text, job_description, parsed.skills)
        score = self.scorer.score(parsed, match, resume_text)
        suggestions = self.suggestions.generate(parsed, match, score)
        return AnalysisReport(parsed=parsed, match=match, score=score, suggestions=suggestions)

    def _job_recommendations(self) -> None:
        if not st.session_state.parsed_resume:
            return
        st.markdown("### Recommended Jobs")
        st.caption("Ranked from local structured job data, ready to replace with an API later.")
        recommendations = self.job_recommender.recommend(st.session_state.parsed_resume.skills)
        if not recommendations:
            st.info("No job data available yet.")
            return
        for item in recommendations:
            with st.container():
                cols = st.columns([1.2, 0.3])
                with cols[0]:
                    st.markdown(f"**{item.title}** at {item.company} · {item.location}")
                    st.caption(item.rationale)
                    pills(item.matched_skills[:6], "good")
                    if item.missing_skills:
                        st.caption("Missing or weak skills")
                        pills(item.missing_skills[:5], "bad")
                with cols[1]:
                    st.metric("Fit", f"{item.match_percentage}%")
                    st.progress(item.match_percentage / 100)

    def _goals_and_activity(self) -> None:
        st.markdown("### Goals and Activity")
        left, right = st.columns([1, 1])
        with left:
            with st.form("goal_form", clear_on_submit=True):
                title = st.text_input("Goal", placeholder="Apply to 10 jobs this week")
                target = st.number_input("Target", min_value=1, max_value=100, value=10)
                submitted = st.form_submit_button("Add Goal")
                if submitted and title.strip():
                    self.user_tracking.add_goal(title.strip(), int(target))
                    st.success("Goal added.")
            goals = self.user_tracking.fetch_goals()
            for goal in goals:
                progress_ratio = min(1.0, goal["progress"] / goal["target"]) if goal["target"] else 0
                st.write(f"{goal['title']} ({goal['progress']}/{goal['target']})")
                st.progress(progress_ratio)
        with right:
            activities = self.user_tracking.fetch_activities()
            if not activities:
                st.caption("No activity yet.")
            for activity in activities:
                st.markdown(f"**{activity['label']}**")
                st.caption(f"{activity['detail']} · {activity['created_at']}")

    def _apply_theme(self) -> None:
        if st.session_state.theme == "Light":
            st.markdown(
                """
                <style>
                .stApp {
                    background: linear-gradient(135deg, #f7f4ff 0%, #e9e3ff 52%, #ffffff 100%);
                }
                .hero-title { color: #171329; }
                .hero-subtitle { color: #5f5980; }
                [data-testid="stSidebar"] { background: #ffffff; }
                [data-testid="stSidebar"] * { color: #171329; }
                </style>
                """,
                unsafe_allow_html=True,
            )

    def _require_resume(self) -> bool:
        if st.session_state.resume_uploaded and st.session_state.parsed_resume:
            return True
        st.warning("Upload your resume first to unlock this step.")
        if st.button("Go to Upload Resume"):
            self._go_to(self.STEPS[0])
        return False

    def _require_match(self) -> bool:
        if self._require_resume() and st.session_state.analysis_report:
            return True
        st.warning("Run the Job Matcher first to unlock this section.")
        if st.button("Go to Job Matcher"):
            self._go_to(self.STEPS[2])
        return False

    def _go_to(self, step: str) -> None:
        st.session_state.current_step = step
        st.rerun()
