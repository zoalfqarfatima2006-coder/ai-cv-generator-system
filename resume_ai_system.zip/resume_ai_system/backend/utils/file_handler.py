import io
import json
from pathlib import Path
from typing import Any


class FileHandler:
    """Read uploaded files and create portable report artifacts."""

    def extract_text(self, uploaded_file: Any) -> str:
        name = getattr(uploaded_file, "name", "")
        suffix = Path(name).suffix.lower()
        content = uploaded_file.getvalue()
        if suffix == ".pdf":
            return self._extract_pdf(content)
        if suffix == ".docx":
            return self._extract_docx(content)
        raise ValueError("Unsupported file type. Please upload a PDF or DOCX resume.")

    def build_pdf_report(self, payload: dict[str, Any]) -> bytes:
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            return json.dumps(payload, indent=2).encode("utf-8")

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, title="AI Resume Intelligence Report")
        styles = getSampleStyleSheet()
        parsed = payload.get("parsed", {})
        match = payload.get("match", {})
        score = payload.get("score", {})

        story = [
            Paragraph("AI Resume Intelligence Report", styles["Title"]),
            Spacer(1, 12),
            Paragraph(f"Candidate: {parsed.get('name') or 'Unknown'}", styles["Heading2"]),
            Paragraph(f"Match Score: {match.get('match_percentage', 0)}%", styles["Normal"]),
            Paragraph(f"ATS Score: {score.get('ats_score', 0)}%", styles["Normal"]),
            Paragraph(f"Overall Score: {score.get('overall_score', 0)}%", styles["Normal"]),
            Spacer(1, 10),
            Paragraph("Missing Skills", styles["Heading2"]),
            Paragraph(", ".join(match.get("missing_skills", [])) or "No major skill gaps detected.", styles["Normal"]),
            Spacer(1, 8),
            Paragraph("Suggestions", styles["Heading2"]),
        ]
        for suggestion in payload.get("suggestions", []):
            story.append(Paragraph(f"- {suggestion}", styles["Normal"]))
        doc.build(story)
        return buffer.getvalue()

    def build_full_analysis_report(
        self,
        payload: dict[str, Any],
        rewritten_resume: str = "",
        recruiter_feedback: dict[str, Any] | None = None,
    ) -> bytes:
        """Build an expanded PDF with analysis, rewriting, and recruiter feedback."""
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            export = dict(payload)
            export["rewritten_resume"] = rewritten_resume
            export["recruiter_feedback"] = recruiter_feedback or {}
            return json.dumps(export, indent=2).encode("utf-8")

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, title="Full Resume Intelligence Report")
        styles = getSampleStyleSheet()
        story = [Paragraph("Full Resume Intelligence Report", styles["Title"]), Spacer(1, 12)]
        for key in ("parsed", "match", "score"):
            story.append(Paragraph(key.replace("_", " ").title(), styles["Heading2"]))
            story.append(Paragraph(json.dumps(payload.get(key, {}), indent=2)[:1800], styles["Code"]))
            story.append(Spacer(1, 8))
        if rewritten_resume:
            story.append(Paragraph("Rewritten Resume", styles["Heading2"]))
            for line in rewritten_resume.splitlines():
                story.append(Paragraph(line or " ", styles["Normal"]))
        if recruiter_feedback:
            story.append(Paragraph("Recruiter Feedback", styles["Heading2"]))
            story.append(Paragraph(json.dumps(recruiter_feedback, indent=2)[:1800], styles["Code"]))
        doc.build(story)
        return buffer.getvalue()

    def build_resume_export(self, resume_text: str, title: str = "Tailored Resume") -> bytes:
        """Export a generated resume as PDF, falling back to UTF-8 text bytes."""
        return self._build_text_pdf(title, resume_text)

    def build_recruiter_feedback_export(self, feedback: dict[str, Any]) -> bytes:
        """Export recruiter-lens feedback as a compact PDF report."""
        return self._build_text_pdf("Recruiter Lens Feedback", json.dumps(feedback, indent=2))

    def _build_text_pdf(self, title: str, text: str) -> bytes:
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
        except ImportError:
            return text.encode("utf-8")

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, title=title)
        styles = getSampleStyleSheet()
        story = [Paragraph(title, styles["Title"]), Spacer(1, 10)]
        for line in text.splitlines():
            story.append(Paragraph(line or " ", styles["Normal"]))
        doc.build(story)
        return buffer.getvalue()

    def _extract_pdf(self, content: bytes) -> str:
        try:
            import pdfplumber
        except ImportError as exc:
            raise RuntimeError("Install pdfplumber to read PDF resumes.") from exc
        with pdfplumber.open(io.BytesIO(content)) as pdf:
            return "\n".join(page.extract_text() or "" for page in pdf.pages)

    def _extract_docx(self, content: bytes) -> str:
        try:
            from docx import Document
        except ImportError as exc:
            raise RuntimeError("Install python-docx to read DOCX resumes.") from exc
        document = Document(io.BytesIO(content))
        return "\n".join(paragraph.text for paragraph in document.paragraphs)
