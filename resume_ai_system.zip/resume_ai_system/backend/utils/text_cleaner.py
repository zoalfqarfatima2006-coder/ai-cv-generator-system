import re
from dataclasses import dataclass


@dataclass(slots=True)
class TextCleaner:
    """Normalize resume and job description text for parsing and matching."""

    def clean(self, text: str) -> str:
        text = text or ""
        text = text.replace("\x00", " ")
        text = text.replace("\u2022", "-")
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n[ \t]+", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def normalize_for_match(self, text: str) -> str:
        text = self.clean(text).lower()
        text = re.sub(r"[^a-z0-9+#.\s/-]", " ", text)
        return re.sub(r"\s+", " ", text).strip()

    def split_sentences(self, text: str) -> list[str]:
        parts = re.split(r"(?<=[.!?])\s+|\n+", self.clean(text))
        return [part.strip() for part in parts if len(part.strip()) > 12]
