"""Offline suggestion generation."""
