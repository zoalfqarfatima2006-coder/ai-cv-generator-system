import html
import re
from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume, ResumeScore


@dataclass(slots=True)
class SuggestionEngine:
    offline_mode: bool = True

    def generate(self, parsed: ParsedResume, match: MatchResult, score: ResumeScore) -> list[str]:
        suggestions: list[str] = []
        if match.missing_skills:
            suggestions.append(f"Add truthful evidence for these role skills: {', '.join(match.missing_skills[:8])}.")
        if score.section_scores.get("experience", 0) < 70:
            suggestions.append("Rewrite experience bullets as action verb + technical scope + measurable result.")
        if score.section_scores.get("format", 0) < 80:
            suggestions.append("Use standard ATS section headers: Skills, Experience, Projects, Education, Certifications.")
        if score.section_scores.get("contact", 0) < 90:
            suggestions.append("Place name, email, phone, LinkedIn, and GitHub or portfolio in the header.")
        if match.match_percentage < 70:
            suggestions.append("Mirror the job description language where it accurately describes your work.")
        if not parsed.education:
            suggestions.append("Add education, certifications, or training so screeners can classify credentials.")
        suggestions.append("Keep the layout simple: avoid tables for core content and keep bullets keyword-rich.")
        return suggestions

    def highlight_keywords(self, text: str, keywords: list[str]) -> str:
        escaped = html.escape(text)
        highlighted = escaped
        for keyword in sorted(set(keywords), key=len, reverse=True)[:30]:
            if len(keyword) < 3:
                continue
            highlighted = re.sub(
                rf"\b({re.escape(html.escape(keyword))})\b",
                r"<mark>\1</mark>",
                highlighted,
                flags=re.I,
            )
        return highlighted
