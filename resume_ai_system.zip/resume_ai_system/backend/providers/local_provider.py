from backend.providers.base_provider import BaseProvider


class LocalProvider(BaseProvider):
    """Rule-based offline provider used when LLMs are disabled or unavailable."""

    def generate_text(self, prompt: str) -> str:
        prompt = " ".join((prompt or "").split())
        if not prompt:
            return "No prompt was provided."
        return (
            "Offline assistant response:\n"
            "- Focus on truthful job keywords from the target role.\n"
            "- Rewrite bullets with action, scope, tool, and measurable outcome.\n"
            "- Keep formatting ATS-friendly with simple section headings.\n\n"
            f"Context used: {prompt[:500]}"
        )
