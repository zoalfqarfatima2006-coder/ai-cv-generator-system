from abc import ABC, abstractmethod


class BaseProvider(ABC):
    """Interface for text generation providers."""

    @abstractmethod
    def generate_text(self, prompt: str) -> str:
        """Return generated text for a prompt."""
