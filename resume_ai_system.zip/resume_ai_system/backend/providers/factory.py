from backend.config import settings
from backend.providers.base_provider import BaseProvider
from backend.providers.gemini_provider import GeminiProvider
from backend.providers.local_provider import LocalProvider
from backend.providers.openai_provider import OpenAIProvider


def get_provider() -> BaseProvider:
    """Return the configured provider while preserving offline-first behavior."""
    if not settings.USE_LLM:
        return LocalProvider()
    if settings.PROVIDER == "openai":
        return OpenAIProvider()
    if settings.PROVIDER == "gemini":
        return GeminiProvider()
    return LocalProvider()
