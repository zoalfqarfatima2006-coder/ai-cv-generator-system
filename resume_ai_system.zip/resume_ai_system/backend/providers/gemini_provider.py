from backend.config import settings
from backend.providers.base_provider import BaseProvider
from backend.providers.local_provider import LocalProvider


class GeminiProvider(BaseProvider):
    """Optional Gemini provider. Falls back locally if the package or key is missing."""

    def __init__(self) -> None:
        self.fallback = LocalProvider()

    def generate_text(self, prompt: str) -> str:
        if not settings.GEMINI_API_KEY:
            return self.fallback.generate_text(prompt)
        try:
            import google.generativeai as genai
        except ImportError:
            return self.fallback.generate_text(prompt)

        genai.configure(api_key=settings.GEMINI_API_KEY)
        model = genai.GenerativeModel(settings.GEMINI_MODEL)
        response = model.generate_content(prompt)
        return getattr(response, "text", "") or self.fallback.generate_text(prompt)
