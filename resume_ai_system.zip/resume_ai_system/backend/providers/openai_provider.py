from backend.config import settings
from backend.providers.base_provider import BaseProvider
from backend.providers.local_provider import LocalProvider


class OpenAIProvider(BaseProvider):
    """Optional OpenAI provider. Falls back locally if the package or key is missing."""

    def __init__(self) -> None:
        self.fallback = LocalProvider()

    def generate_text(self, prompt: str) -> str:
        if not settings.OPENAI_API_KEY:
            return self.fallback.generate_text(prompt)
        try:
            from openai import OpenAI
        except ImportError:
            return self.fallback.generate_text(prompt)

        client = OpenAI(api_key=settings.OPENAI_API_KEY)
        response = client.chat.completions.create(
            model=settings.OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "You are a concise career assistant."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.4,
        )
        return response.choices[0].message.content or ""
