"""Resume parsing and skill extraction."""
