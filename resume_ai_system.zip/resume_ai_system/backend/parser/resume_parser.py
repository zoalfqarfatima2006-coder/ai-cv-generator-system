import re
from dataclasses import dataclass, field

from backend.models.resume_model import ParsedResume
from backend.parser.skill_extractor import SkillExtractor
from backend.utils.text_cleaner import TextCleaner


@dataclass(slots=True)
class ResumeParser:
    skill_extractor: SkillExtractor = field(default_factory=SkillExtractor)
    cleaner: TextCleaner = field(default_factory=TextCleaner)

    SECTION_NAMES = {
        "summary", "profile", "objective", "experience", "work experience", "employment",
        "professional experience", "education", "skills", "technical skills", "projects",
        "certifications", "achievements", "awards", "publications",
    }
    DEGREE_PATTERNS = [
        r"\b(?:bachelor|master|phd|doctorate|associate|diploma)\b[^\n,.]*",
        r"\b(?:b\.?s\.?|m\.?s\.?|b\.?a\.?|m\.?a\.?|mba|btech|mtech|b\.?e\.?|m\.?e\.?)\b[^\n,.]*",
    ]

    def parse(self, text: str) -> ParsedResume:
        clean_text = self.cleaner.clean(text)
        sections = self._extract_sections(clean_text)
        email = self._extract_email(clean_text)
        phone = self._extract_phone(clean_text)
        linkedin = self._extract_url(clean_text, "linkedin.com")
        github = self._extract_url(clean_text, "github.com")
        return ParsedResume(
            name=self._extract_name(clean_text, email),
            email=email,
            phone=phone,
            skills=self.skill_extractor.extract(clean_text),
            experience_years=self._estimate_experience(clean_text),
            education=self._extract_education(clean_text, sections),
            contact_info={"email": email, "phone": phone, "linkedin": linkedin, "github": github},
            sections=sections,
            raw_text=clean_text,
        )

    def _extract_email(self, text: str) -> str | None:
        match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
        return match.group(0) if match else None

    def _extract_phone(self, text: str) -> str | None:
        match = re.search(r"(?:(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)\d{3}[\s.-]?\d{4})", text)
        return match.group(0) if match else None

    def _extract_url(self, text: str, domain: str) -> str | None:
        match = re.search(rf"(?:https?://)?(?:www\.)?{re.escape(domain)}/[^\s)]+", text, re.I)
        return match.group(0) if match else None

    def _extract_name(self, text: str, email: str | None) -> str | None:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        for line in lines[:10]:
            if email and email in line:
                continue
            if re.search(r"resume|curriculum vitae|email|phone|linkedin|github|portfolio", line, re.I):
                continue
            words = re.findall(r"[A-Z][a-zA-Z'-]+", line)
            if 2 <= len(words) <= 4 and len(line) <= 70:
                return " ".join(words)
        return None

    def _extract_education(self, text: str, sections: dict[str, str]) -> list[str]:
        source = sections.get("education", text)
        found: list[str] = []
        for pattern in self.DEGREE_PATTERNS:
            found.extend(match.group(0).strip(" -") for match in re.finditer(pattern, source, re.I))
        found.extend(
            line.strip()
            for line in source.splitlines()
            if re.search(r"university|college|institute|school|academy", line, re.I)
        )
        return sorted(set(found), key=str.lower)[:8]

    def _estimate_experience(self, text: str) -> float:
        explicit = re.findall(r"(\d+(?:\.\d+)?)\+?\s*(?:years?|yrs?)", text, re.I)
        if explicit:
            return max(float(value) for value in explicit)
        years = [int(year) for year in re.findall(r"\b(20\d{2}|19\d{2})\b", text)]
        sensible = [year for year in years if 1980 <= year <= 2035]
        if len(sensible) >= 2:
            return float(max(sensible) - min(sensible))
        return 0.0

    def _extract_sections(self, text: str) -> dict[str, str]:
        sections: dict[str, list[str]] = {"full_text": [text]}
        current = "summary"
        sections[current] = []
        for line in text.splitlines():
            key = line.strip().lower().rstrip(":")
            if key in self.SECTION_NAMES and len(key) <= 32:
                current = key
                sections.setdefault(current, [])
                continue
            sections.setdefault(current, []).append(line)
        return {
            key: "\n".join(value).strip()
            for key, value in sections.items()
            if "\n".join(value).strip()
        }
