import re
from dataclasses import dataclass, field

from backend.utils.text_cleaner import TextCleaner


DEFAULT_SKILLS = {
    "python", "java", "javascript", "typescript", "c", "c++", "c#", "sql", "html", "css",
    "react", "angular", "vue", "node.js", "express", "django", "flask", "fastapi",
    "spring boot", "streamlit", "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch",
    "keras", "machine learning", "deep learning", "nlp", "natural language processing",
    "computer vision", "data analysis", "data visualization", "power bi", "tableau",
    "excel", "git", "github", "docker", "kubernetes", "aws", "azure", "gcp", "linux",
    "bash", "rest api", "graphql", "postgresql", "mysql", "sqlite", "mongodb", "redis",
    "etl", "airflow", "spark", "hadoop", "ci/cd", "jenkins", "terraform", "agile",
    "scrum", "jira", "figma", "project management", "leadership", "communication",
    "problem solving", "stakeholder management", "salesforce", "crm", "seo",
    "content strategy", "financial modeling", "statistics", "a/b testing",
    "product management", "api", "microservices", "cloud", "devops", "powerpoint",
}


@dataclass(slots=True)
class SkillExtractor:
    skills: set[str] = field(default_factory=lambda: set(DEFAULT_SKILLS))
    cleaner: TextCleaner = field(default_factory=TextCleaner)

    def extract(self, text: str) -> list[str]:
        normalized = f" {self.cleaner.normalize_for_match(text)} "
        found: list[str] = []
        for skill in sorted(self.skills, key=len, reverse=True):
            pattern = r"(?<![a-z0-9+#.])" + re.escape(skill.lower()) + r"(?![a-z0-9+#.])"
            if re.search(pattern, normalized):
                found.append(self._display(skill))
        return sorted(set(found), key=str.lower)

    def extract_weighted_keywords(self, text: str, limit: int = 30) -> list[str]:
        normalized = self.cleaner.normalize_for_match(text)
        tokens = re.findall(r"\b[a-z][a-z0-9+#./-]{2,}\b", normalized)
        stop = {
            "and", "the", "with", "for", "you", "our", "are", "will", "from", "this",
            "that", "have", "has", "your", "using", "work", "team", "role", "job",
            "experience", "skills", "ability", "required", "preferred", "candidate",
            "responsibilities", "requirements", "years",
        }
        counts: dict[str, int] = {}
        for token in tokens:
            if token not in stop and len(token) > 2:
                counts[token] = counts.get(token, 0) + 1
        skill_keywords = [skill.lower() for skill in self.extract(text)]
        ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        merged = skill_keywords + [word for word, _ in ranked]
        return list(dict.fromkeys(merged))[:limit]

    def _display(self, skill: str) -> str:
        aliases = {
            "sql": "SQL", "aws": "AWS", "gcp": "GCP", "nlp": "NLP", "ci/cd": "CI/CD",
            "api": "API", "rest api": "REST API", "html": "HTML", "css": "CSS",
        }
        return aliases.get(skill.lower(), skill.title())
