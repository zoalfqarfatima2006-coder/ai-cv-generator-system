import math
import re
from collections import Counter
from dataclasses import dataclass, field

from backend.utils.text_cleaner import TextCleaner


@dataclass(slots=True)
class SimilarityEngine:
    """Small offline TF-IDF cosine engine for two-document matching."""

    cleaner: TextCleaner = field(default_factory=TextCleaner)

    def calculate(self, resume_text: str, job_description: str) -> float:
        resume_tokens = self._tokens(resume_text)
        jd_tokens = self._tokens(job_description)
        if not resume_tokens or not jd_tokens:
            return 0.0

        resume_tf = Counter(resume_tokens)
        jd_tf = Counter(jd_tokens)
        vocabulary = sorted(set(resume_tf) | set(jd_tf))
        left = [self._tfidf(term, resume_tf, jd_tf) for term in vocabulary]
        right = [self._tfidf(term, jd_tf, resume_tf) for term in vocabulary]
        return round(self._cosine(left, right), 4)

    def _tokens(self, text: str) -> list[str]:
        normalized = self.cleaner.normalize_for_match(text)
        stop = {
            "the", "and", "for", "with", "you", "are", "will", "this", "that", "from",
            "our", "your", "have", "has", "job", "role", "team", "work",
        }
        return [
            token
            for token in re.findall(r"\b[a-z][a-z0-9+#./-]{2,}\b", normalized)
            if token not in stop
        ]

    def _tfidf(self, term: str, doc: Counter, other: Counter) -> float:
        term_frequency = doc.get(term, 0)
        docs_with_term = int(term in doc) + int(term in other)
        inverse_doc_frequency = math.log((2 + 1) / (docs_with_term + 1)) + 1
        return term_frequency * inverse_doc_frequency

    def _cosine(self, left: list[float], right: list[float]) -> float:
        dot = sum(a * b for a, b in zip(left, right))
        left_norm = math.sqrt(sum(a * a for a in left))
        right_norm = math.sqrt(sum(b * b for b in right))
        return dot / (left_norm * right_norm) if left_norm and right_norm else 0.0
