from dataclasses import dataclass, field

from backend.matcher.similarity import SimilarityEngine
from backend.models.resume_model import MatchResult
from backend.parser.skill_extractor import SkillExtractor


@dataclass(slots=True)
class ResumeMatcher:
    skill_extractor: SkillExtractor = field(default_factory=SkillExtractor)
    similarity_engine: SimilarityEngine = field(default_factory=SimilarityEngine)

    def match(self, resume_text: str, job_description: str, resume_skills: list[str] | None = None) -> MatchResult:
        resume_skill_display = {skill.lower(): skill for skill in (resume_skills or self.skill_extractor.extract(resume_text))}
        jd_skills = self.skill_extractor.extract(job_description)
        jd_skill_display = {skill.lower(): skill for skill in jd_skills}
        resume_skill_set = set(resume_skill_display)
        jd_skill_set = {skill.lower() for skill in jd_skills}

        matched = sorted(jd_skill_set & resume_skill_set)
        missing = sorted(jd_skill_set - resume_skill_set)
        semantic_similarity = self.similarity_engine.calculate(resume_text, job_description)
        skill_coverage = len(matched) / len(jd_skill_set) if jd_skill_set else 0.0
        combined = (semantic_similarity * 0.62) + (skill_coverage * 0.38)

        return MatchResult(
            match_percentage=max(0, min(100, round(combined * 100))),
            semantic_similarity=semantic_similarity,
            skill_coverage=round(skill_coverage, 4),
            matched_skills=[jd_skill_display.get(skill, resume_skill_display.get(skill, skill)) for skill in matched],
            missing_skills=[jd_skill_display.get(skill, skill) for skill in missing],
            jd_keywords=self.skill_extractor.extract_weighted_keywords(job_description),
        )
