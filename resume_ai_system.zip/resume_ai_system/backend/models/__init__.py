"""Data models used across backend modules."""
