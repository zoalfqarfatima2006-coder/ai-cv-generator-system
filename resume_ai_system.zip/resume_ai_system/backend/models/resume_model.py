from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ParsedResume:
    name: str | None
    email: str | None
    phone: str | None
    skills: list[str]
    experience_years: float
    education: list[str]
    contact_info: dict[str, str | None]
    sections: dict[str, str]
    raw_text: str = ""


@dataclass(slots=True)
class MatchResult:
    match_percentage: int
    semantic_similarity: float
    skill_coverage: float
    matched_skills: list[str] = field(default_factory=list)
    missing_skills: list[str] = field(default_factory=list)
    jd_keywords: list[str] = field(default_factory=list)


@dataclass(slots=True)
class ResumeScore:
    overall_score: int
    ats_score: int
    section_scores: dict[str, int]
    strengths: list[str]
    risks: list[str]


@dataclass(slots=True)
class AnalysisReport:
    parsed: ParsedResume
    match: MatchResult
    score: ResumeScore
    suggestions: list[str]

    def as_dict(self) -> dict[str, Any]:
        from dataclasses import asdict

        return asdict(self)
