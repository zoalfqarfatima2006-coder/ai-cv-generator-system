import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any


class ResumeDatabase:
    """Tiny SQLite repository for local analysis history."""

    def __init__(self, db_path: str | Path = "data/resume_ai.sqlite3") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def save_analysis(self, payload: dict[str, Any]) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO analyses(created_at, candidate_name, match_score, ats_score, payload)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    datetime.utcnow().isoformat(timespec="seconds"),
                    payload.get("parsed", {}).get("name") or "Unknown",
                    payload.get("match", {}).get("match_percentage", 0),
                    payload.get("score", {}).get("ats_score", 0),
                    json.dumps(payload),
                ),
            )
            return int(cursor.lastrowid)

    def fetch_recent(self, limit: int = 10) -> list[dict[str, Any]]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT id, created_at, candidate_name, match_score, ats_score
                FROM analyses
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    def save_master_profile(self, name: str, payload: dict[str, Any]) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "INSERT INTO master_profiles(created_at, name, payload) VALUES (?, ?, ?)",
                (datetime.utcnow().isoformat(timespec="seconds"), name or "Unknown", json.dumps(payload)),
            )
            return int(cursor.lastrowid)

    def save_resume_version(self, profile_id: int | None, title: str, content: str) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "INSERT INTO resume_versions(created_at, profile_id, title, content) VALUES (?, ?, ?, ?)",
                (datetime.utcnow().isoformat(timespec="seconds"), profile_id, title, content),
            )
            return int(cursor.lastrowid)

    def save_skill_roi_log(self, skill: str, demand_score: int, payload: dict[str, Any]) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "INSERT INTO skill_roi_logs(created_at, skill, demand_score, payload) VALUES (?, ?, ?, ?)",
                (datetime.utcnow().isoformat(timespec="seconds"), skill, demand_score, json.dumps(payload)),
            )
            return int(cursor.lastrowid)

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS analyses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    candidate_name TEXT,
                    match_score REAL,
                    ats_score REAL,
                    payload TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS master_profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    name TEXT,
                    payload TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS applications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    company TEXT NOT NULL,
                    role TEXT NOT NULL,
                    date_applied TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS resume_versions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    profile_id INTEGER,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS skill_roi_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    skill TEXT NOT NULL,
                    demand_score INTEGER NOT NULL,
                    payload TEXT NOT NULL
                )
                """
            )
