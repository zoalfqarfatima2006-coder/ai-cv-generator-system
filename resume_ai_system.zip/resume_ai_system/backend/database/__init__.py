"""SQLite persistence package."""
