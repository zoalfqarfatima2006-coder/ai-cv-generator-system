from dataclasses import dataclass

from backend.models.resume_model import MatchResult, ParsedResume, ResumeScore


@dataclass(slots=True)
class ResumeScorer:
    """Score resumes for ATS readiness, completeness, and JD alignment."""

    def score(self, parsed: ParsedResume, match: MatchResult, resume_text: str) -> ResumeScore:
        section_scores = {
            "contact": self._score_contact(parsed),
            "skills": min(100, 20 + len(parsed.skills) * 7),
            "experience": self._score_experience(parsed),
            "education": 90 if parsed.education else 35,
            "job_keywords": match.match_percentage,
            "format": self._score_format(resume_text),
        }
        ats_score = round(
            section_scores["contact"] * 0.15
            + section_scores["skills"] * 0.2
            + section_scores["experience"] * 0.2
            + section_scores["education"] * 0.1
            + section_scores["job_keywords"] * 0.25
            + section_scores["format"] * 0.1
        )
        overall_score = round(ats_score * 0.7 + match.match_percentage * 0.3)
        return ResumeScore(
            overall_score=overall_score,
            ats_score=ats_score,
            section_scores=section_scores,
            strengths=self._strengths(parsed, match, section_scores),
            risks=self._risks(parsed, match, section_scores),
        )

    def _score_contact(self, parsed: ParsedResume) -> int:
        score = 20
        score += 30 if parsed.name else 0
        score += 25 if parsed.email else 0
        score += 15 if parsed.phone else 0
        score += 10 if parsed.contact_info.get("linkedin") or parsed.contact_info.get("github") else 0
        return min(100, score)

    def _score_experience(self, parsed: ParsedResume) -> int:
        if parsed.experience_years >= 5:
            return 95
        if parsed.experience_years >= 2:
            return 78
        if parsed.experience_years > 0:
            return 62
        experience_text = parsed.sections.get("experience") or parsed.sections.get("professional experience", "")
        return 55 if len(experience_text.split()) > 60 else 35

    def _score_format(self, text: str) -> int:
        score = 50
        lowered = text.lower()
        for section in ("experience", "education", "skills", "projects"):
            score += 9 if section in lowered else 0
        score += 9 if any(marker in text for marker in ("-", "*")) else 0
        score += 5 if len(text.split()) >= 250 else 0
        return min(100, score)

    def _strengths(self, parsed: ParsedResume, match: MatchResult, sections: dict[str, int]) -> list[str]:
        strengths: list[str] = []
        if sections["contact"] >= 80:
            strengths.append("Contact details are complete and ATS-readable.")
        if len(parsed.skills) >= 8:
            strengths.append("The resume exposes a broad set of detectable skills.")
        if match.matched_skills:
            strengths.append(f"Strong job overlap: {', '.join(match.matched_skills[:6])}.")
        if sections["format"] >= 80:
            strengths.append("Core resume sections are clearly labeled.")
        return strengths or ["The resume has enough content for a baseline analysis."]

    def _risks(self, parsed: ParsedResume, match: MatchResult, sections: dict[str, int]) -> list[str]:
        risks: list[str] = []
        if sections["contact"] < 75:
            risks.append("Contact information may be incomplete or hard for an ATS to extract.")
        if sections["experience"] < 55:
            risks.append("Experience signals are thin; add roles, dates, tools, and measurable outcomes.")
        if match.missing_skills:
            risks.append(f"Missing job-critical skills: {', '.join(match.missing_skills[:8])}.")
        if sections["format"] < 75:
            risks.append("Formatting may need clearer standard headings for ATS parsing.")
        return risks
