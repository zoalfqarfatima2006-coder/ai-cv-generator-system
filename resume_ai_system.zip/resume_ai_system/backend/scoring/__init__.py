"""Resume and ATS scoring services."""
